/**
 * 
 */
package com.capgemini.paymentwallet.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

/**
 * @author smitkuma
 *
 */
public class WalletAccount {
	private BigInteger accId;
	private User user;
	private BigDecimal accBalance;
	private static long numId;
	private List<TransactionHistory> transactionHistories;
	//static initializer block
	static {
		//for auto-generating userId
		numId= (long) (1000000+ (Math.random()*123456.123456));
	}
	//initializer block
	{
		accId= BigInteger.valueOf(numId++);
	}
	public WalletAccount(BigDecimal accBalance, User user) {
		super();
		this.accBalance = accBalance;
		this.user = user;
	}
	public WalletAccount() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accBalance == null) ? 0 : accBalance.hashCode());
		result = prime * result + ((accId == null) ? 0 : accId.hashCode());
		result = prime * result + ((transactionHistories == null) ? 0 : transactionHistories.hashCode());
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WalletAccount other = (WalletAccount) obj;
		if (accBalance == null) {
			if (other.accBalance != null)
				return false;
		} else if (!accBalance.equals(other.accBalance))
			return false;
		if (accId == null) {
			if (other.accId != null)
				return false;
		} else if (!accId.equals(other.accId))
			return false;
		if (transactionHistories == null) {
			if (other.transactionHistories != null)
				return false;
		} else if (!transactionHistories.equals(other.transactionHistories))
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "WalletAccount [accId=" + accId + ", accBalance=" + accBalance + "]";
	}
	public BigInteger getAccId() {
		return accId;
	}
	public void setAccId(BigInteger accId) {
		this.accId = accId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public BigDecimal getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(BigDecimal accBalance) {
		this.accBalance = accBalance;
	}
	public List<TransactionHistory> getTransactionHistories() {
		return transactionHistories;
	}
	public void setTransactionHistories(List<TransactionHistory> transactionHistories) {
		this.transactionHistories = transactionHistories;
	}
}
