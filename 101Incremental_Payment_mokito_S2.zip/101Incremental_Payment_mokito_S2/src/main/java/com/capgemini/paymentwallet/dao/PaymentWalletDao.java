/**
 * 
 */
package com.capgemini.paymentwallet.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.User;
import com.capgemini.paymentwallet.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public class PaymentWalletDao implements IPaymentWalletDao {
	
	private static List<User> users;
	static {
		 users = UserDb.getUsers();
	}


	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#register(com.capgemini.paymentwallet.model.User)
	 */
	@Override
	public User register(User user) throws PaymentWalletException {
		// adding new user to the exiting users list
		return(users.add(user)?user:null);// if user added successfully then return user object else return null
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#login(com.capgemini.paymentwallet.model.User)
	 */
	@Override
	public boolean login(User user) throws PaymentWalletException {
		String uname=user.getUsername();
		String pass=user.getPassword();
		boolean status =false;
		outer:for(User u1 : users) {
			if(u1.getUsername().equals(uname) && u1.getPassword().equals(pass)) {
				status=true;//if user exists then setting the status to true
				break outer;
			}
		}
		return status;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#addMoney(java.lang.BigInteger, java.lang.BigInteger, java.lang.BigDecimal)
	 */
	@Override
	public WalletAccount addMoney(BigInteger accId, BigInteger pin, double amount) throws PaymentWalletException {
		WalletAccount walletAccount=null;
		outer:for(User u1 : users) {
			walletAccount=u1.getWalletAccount();
			int index = users.indexOf(u1);
			BigDecimal accBalance = walletAccount.getAccBalance();
			if(walletAccount.getAccId().equals(accId)&& u1.getPin().equals(pin)) {
				accBalance= BigDecimal.valueOf(amount).add(accBalance);//adding amount to exiting balance
				walletAccount.setAccBalance(accBalance);//updating the wallet balance
				u1.setWalletAccount(walletAccount); //setting the updated wallet to u1
				users.set(index,u1);//updating the user after updating the wallet amount
				break outer;
			}else {
				walletAccount=null;//if walletAccount accId and pin doesNot match then it will refer to null
			}
		}		
		return walletAccount;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#checkBalance(java.lang.BigInteger, java.lang.BigInteger)
	 */
	@Override
	public BigDecimal checkBalance(BigInteger accId, BigInteger pin) throws PaymentWalletException {
		BigDecimal accBalance =new BigDecimal(0);
		WalletAccount walletAccount=null;
		outer:for(User u1 : users) {
			walletAccount=u1.getWalletAccount();
			if(walletAccount.getAccId().equals(accId) && u1.getPin().equals(pin) ) {
				accBalance=walletAccount.getAccBalance();
				System.out.println(" accBalance at dao "+accBalance);
				break outer;
			}
		}		
		return accBalance;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#viewWallet(java.lang.BigInteger, java.lang.BigInteger)
	 */
	@Override
	public WalletAccount viewWallet(BigInteger accId, BigInteger pin) throws PaymentWalletException {
		WalletAccount walletAccount=null;
		outer:for(User u1 : users) {
			walletAccount=u1.getWalletAccount();
			if(walletAccount.getAccId().equals(accId)&& u1.getPin().equals(pin)) {
				break outer;
			}else {
				walletAccount=null;
			}
		}		
		return walletAccount;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#fundTransfer(java.lang.BigInteger, java.lang.BigInteger, java.lang.BigInteger)
	 */
	@Override
	public TransactionHistory fundTransfer(BigInteger pin, BigInteger fromAccId, BigInteger toAccId, double amount)
			throws PaymentWalletException {
		WalletAccount walletAccountFrom=null;
		WalletAccount walletAccountTo=null;
		User userFrom =null;
		User userTo =null;
		TransactionHistory transactionHistory=null;
		int indexFrom=0;
		int indexTo=1;
		for(User u1 : users) {//both account should exists in the list then only fund transfer can happen
			
			if(u1.getWalletAccount().getAccId().equals(fromAccId) && u1.getPin().equals(pin)) {
				 userFrom =u1; 
				 indexFrom=users.indexOf(u1);
			}
			if(u1.getWalletAccount().getAccId().equals(toAccId)) {
				 userTo =u1;
				 indexTo=users.indexOf(u1);
			}			
		}	

		List<TransactionHistory> transactionHistories = new ArrayList<>();
		
		// if both account exists in the list then lets  transfer the fund
		if(userFrom!=null && userTo !=null) {
			walletAccountFrom = userFrom.getWalletAccount();
			BigDecimal fromAccBal =walletAccountFrom.getAccBalance();
			fromAccBal.subtract(BigDecimal.valueOf(amount));
			walletAccountFrom.setAccBalance(fromAccBal);
			walletAccountTo = userTo.getWalletAccount();
			BigDecimal toAccBal =walletAccountTo.getAccBalance();
			toAccBal.add(BigDecimal.valueOf(amount));
			walletAccountTo.setAccBalance(toAccBal);
			
			userFrom.setWalletAccount(walletAccountFrom);
			userFrom.setWalletAccount(walletAccountTo);
			
			users.set(indexFrom, userFrom);
			users.set(indexTo, userTo);
			
			transactionHistory = new TransactionHistory(walletAccountFrom, LocalDateTime.now(), "Fund Transfer", 0.0, amount, "Fund Transfer to acc Id"+walletAccountTo.getAccId());
			//adding transaction to transactionList
			transactionHistories.add(transactionHistory);
			walletAccountFrom.setTransactionHistories(transactionHistories);
			
			transactionHistory = new TransactionHistory(walletAccountTo, LocalDateTime.now(), "Fund Transfer", amount, 0.0, "Fund Transfer from acc Id"+walletAccountFrom.getAccId());
			//adding transaction to transactionList
			transactionHistories.add(transactionHistory);
			walletAccountTo.setTransactionHistories(transactionHistories);
		}
		
		return transactionHistory;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#viewtxHistory(java.time.LocalDateTime, java.time.LocalDateTime)
	 */
	@Override
	public List<TransactionHistory> viewtxHistory(BigInteger accId, BigInteger pin,LocalDateTime toDate, LocalDateTime fromDate)
			throws PaymentWalletException {
		List<TransactionHistory> transactionHistories = new ArrayList<>();
		WalletAccount walletAccount=null;
		outer:for(User u1 : users) {
			walletAccount=u1.getWalletAccount();
			if(walletAccount.getAccId().equals(accId) && u1.getPin().equals(pin) ) {
				transactionHistories=walletAccount.getTransactionHistories();
				break outer;
			}
		}		
		return transactionHistories;
	}
	public List<User> getUsers() {
		return users;
	}

}
