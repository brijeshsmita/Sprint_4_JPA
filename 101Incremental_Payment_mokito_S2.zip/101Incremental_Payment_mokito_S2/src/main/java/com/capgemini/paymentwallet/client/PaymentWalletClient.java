/**
 * 
 */
package com.capgemini.paymentwallet.client;

/**
 * @author smitkuma
 *
 */
public class PaymentWalletClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
