/**
 * 
 */
package com.capgemini.paymentwallet.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.paymentwallet.dao.PaymentWalletDao;
import com.capgemini.paymentwallet.dao.UserDb;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.User;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.services.PaymentWalletService;

/**
 * @author smitkuma
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WalletCollectionTest {
	
	 @InjectMocks
	 PaymentWalletService  paymentWalletService;
	
	@Mock
	PaymentWalletDao paymentWalletDao;
	
	
	/**
	 * @throws java.lang.Exception
	 */
	/*@BeforeAll
	public void setup() {
		//if we don't call below, we will get NullPointerException
		//paymentWalletDao= Mockito.mock(IPaymentWalletDao.class);
		paymentWalletDao= Mockito.mock(IPaymentWalletDao.class);
	}*/
	
	@Test 
	public void testUserDb() throws PaymentWalletException {
		List<User> users=UserDb.getUsers();
		assertNotNull("No Users DB Exists !!!", users);
		users.forEach(System.out::println);
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#addMoney(java.lang.Long, java.lang.Integer, java.lang.BigDecimal)}.
	 * @throws PaymentWalletException 
	 */
	@Test
	public void testAddMoney() throws PaymentWalletException {
		
		    WalletAccount walletAccount1= new WalletAccount();
			User u1 = new User("mona", "mona", BigInteger.valueOf(1234), "Mona", "Gupta", new BigInteger("9870006622"), "Mumbai");
			walletAccount1.setAccBalance(BigDecimal.valueOf(1000.00));
			walletAccount1.setAccId(BigInteger.valueOf(1001));
			walletAccount1.setUser(u1);
			u1.setWalletAccount(walletAccount1);
			walletAccount1=paymentWalletService.addMoney(BigInteger.valueOf(1001), BigInteger.valueOf(1234), 1000.00);
			//assertNotNull("Account Does Not exists", walletAccount1);
			BigDecimal actual= walletAccount1.getAccBalance();
			BigDecimal expected=BigDecimal.valueOf(2000.0);
			assertEquals(actual,expected);
			System.out.println(" walletAccount updated balance "+expected);
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#checkBalance(java.lang.Long, java.lang.Integer)}.
	 * @throws PaymentWalletException 
	 */
	@Test 
	public void testCheckBalance() throws PaymentWalletException {
		BigDecimal expected=new BigDecimal("1000.0");
		BigDecimal accBalance=paymentWalletService.checkBalance(BigInteger.valueOf(1002), BigInteger.valueOf(1234));
		assertEquals(expected,accBalance);
		System.out.println(" walletAccount Balance of acc 1002 is "+accBalance);
		
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#viewWallet(java.lang.Long, java.lang.Integer)}.
	 * @throws PaymentWalletException 
	 */
	@Test 
	public void testViewWallet() throws PaymentWalletException {
		
		WalletAccount walletAccount=paymentWalletService.viewWallet(BigInteger.valueOf(1001), BigInteger.valueOf(1234));
		assertNotNull("Account Does Not exists", walletAccount);
		System.out.println(" walletAccount "+walletAccount);		
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#fundTransfer(java.lang.Integer, java.lang.Long, java.lang.Long, java.lang.BigDecimal)}.
	 * @throws PaymentWalletException 
	 */
	@Test 
	public void testFundTransfer() throws PaymentWalletException {
		TransactionHistory transactionHistory=paymentWalletService.fundTransfer(BigInteger.valueOf(1234), BigInteger.valueOf(1001), BigInteger.valueOf(1002), 200.00);
		assertNotNull("Transaction not happened", transactionHistory);
		System.out.println(" transactionHistory "+transactionHistory);
	}

}
