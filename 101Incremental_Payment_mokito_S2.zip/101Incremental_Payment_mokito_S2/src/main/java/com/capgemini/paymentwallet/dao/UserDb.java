/**
 * 
 */
package com.capgemini.paymentwallet.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.paymentwallet.model.User;
import com.capgemini.paymentwallet.model.WalletAccount;

/**
 * @author smitkuma
 * This class is acting as static database for User and WalletAccount class
 */
public class UserDb {

	private static List<User> users;
	static
	{
		users= new ArrayList<User>();
		//creating user and his WalletAccount by calling both entity setter method as we have 1 to 1 association
		WalletAccount walletAccount1= new WalletAccount();
		User u1 = new User("mona", "mona", BigInteger.valueOf(1234), "Mona", "Gupta", new BigInteger("9870006622"), "Mumbai");
		walletAccount1.setAccBalance(BigDecimal.valueOf(1000.00));
		walletAccount1.setAccId(BigInteger.valueOf(1001L));
		walletAccount1.setUser(u1);
		u1.setWalletAccount(walletAccount1);
		
		//2nd user
		WalletAccount walletAccount2= new WalletAccount();
		User u2 = new User("sia", "sia", BigInteger.valueOf(1234), "Sia", "Gupta", new BigInteger("9870003333"), "Pune");
		walletAccount2.setAccBalance(BigDecimal.valueOf(1000.00));
		walletAccount2.setAccId(BigInteger.valueOf(1002L));
		walletAccount2.setUser(u2);
		u2.setWalletAccount(walletAccount2);
		
		//adding both the user to list
		users.add(u1);
		users.add(u2);
	}

	public static List<User> getUsers() {
		return users;
	}

	public static void setUsers(List<User> users) {
		UserDb.users = users;
	}
	
}
