/**
 * 
 */
package com.capgemini.paymentwallet.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import com.capgemini.paymentwallet.dao.IPaymentWalletDao;
import com.capgemini.paymentwallet.dao.PaymentWalletDao;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.User;
import com.capgemini.paymentwallet.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public class PaymentWalletService implements IPaymentWalletService {
	//prep work create instance of dao layer
	private static IPaymentWalletDao paymentWalletDao;
	static {
		paymentWalletDao=new PaymentWalletDao();
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#register(com.capgemini.paymentwallet.model.User)
	 */
	@Override
	public User register(User user) throws PaymentWalletException {
		// TODO Auto-generated method stub
		return paymentWalletDao.register(user);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#login(com.capgemini.paymentwallet.model.User)
	 */
	@Override
	public boolean login(User user) throws PaymentWalletException {
		// TODO Auto-generated method stub
		return paymentWalletDao.login(user);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#addMoney(java.lang.BigInteger, java.lang.BigInteger, java.lang.BigDecimal)
	 */
	@Override
	public WalletAccount addMoney(BigInteger accId, BigInteger pin, double amount) throws PaymentWalletException {
		// TODO Auto-generated method stub
		return paymentWalletDao.addMoney(accId, pin, amount);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#checkBalance(java.lang.BigInteger, java.lang.BigInteger)
	 */
	@Override
	public BigDecimal checkBalance(BigInteger accId, BigInteger pin) throws PaymentWalletException {
		// TODO Auto-generated method stub
		return paymentWalletDao.checkBalance(accId, pin);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#viewWallet(java.lang.BigInteger, java.lang.BigInteger)
	 */
	@Override
	public WalletAccount viewWallet(BigInteger accId, BigInteger pin) throws PaymentWalletException {
		// TODO Auto-generated method stub
		return paymentWalletDao.viewWallet(accId, pin);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#fundTransfer(java.lang.BigInteger, java.lang.BigInteger, java.lang.BigInteger)
	 */
	@Override
	public TransactionHistory fundTransfer(BigInteger pin, BigInteger fromAccId, BigInteger toAccId, double amount)
			throws PaymentWalletException {
		// TODO Auto-generated method stub
		return paymentWalletDao.fundTransfer(pin, fromAccId, toAccId,amount);
	}

	/* (non-Javadoc)
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#viewtxHistory(java.time.LocalDateTime, java.time.LocalDateTime)
	 */
	@Override
	public List<TransactionHistory> viewtxHistory(BigInteger accId, BigInteger pin,LocalDateTime toDate, LocalDateTime fromDate)
			throws PaymentWalletException {
		// TODO Auto-generated method stub
		return paymentWalletDao.viewtxHistory(accId, pin,toDate, fromDate);
	}

	public static IPaymentWalletDao getPaymentWalletDao() {
		return paymentWalletDao;
	}

	public static void setPaymentWalletDao(IPaymentWalletDao paymentWalletDao) {
		PaymentWalletService.paymentWalletDao = paymentWalletDao;
	}

}
