/**
 * 
 */
package com.capgemini.paymentwallet.model;

import java.math.BigInteger;

/**
 * @author smitkuma
 * 
 */
public class User {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((pin == null) ? 0 : pin.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (pin == null) {
			if (other.pin != null)
				return false;
		} else if (!pin.equals(other.pin))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	private BigInteger userId;
	private String username;
	private String password;
	private BigInteger pin;
	private String firstName ;
	private String lastName ;
	private BigInteger mobileNo ;
	private String address ;
	private WalletAccount walletAccount ;
	
	private static long numId;
	//static initializer block
	static {
		//for auto-generating userId
		numId= (long) (10000+ (Math.random()*1234.1234));
	}
	//initializer block
	{
		userId= BigInteger.valueOf(numId);
	}
	public User() {
		// TODO Auto-generated constructor stub
	}
	public User(String username, String password, BigInteger pin, String firstName, String lastName, BigInteger mobileNo,
			String address) {
		super();
		this.username = username;
		this.password = password;
		this.pin = pin;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.address = address;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", username=" + username + ", password=" + password + ", pin=" + pin
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", mobileNo=" + mobileNo + ", address="
				+ address + ", walletAccount=" + walletAccount + "]";
	}
	public BigInteger getUserId() {
		return userId;
	}
	public void setUserId(BigInteger userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public BigInteger getPin() {
		return pin;
	}
	public void setPin(BigInteger pin) {
		this.pin = pin;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public BigInteger getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(BigInteger mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public WalletAccount getWalletAccount() {
		return walletAccount;
	}
	public void setWalletAccount(WalletAccount walletAccount) {
		this.walletAccount = walletAccount;
	}
}
