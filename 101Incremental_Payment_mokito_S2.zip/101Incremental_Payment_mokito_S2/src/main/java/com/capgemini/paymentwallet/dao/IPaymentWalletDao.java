/**
 * 
 */
package com.capgemini.paymentwallet.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.User;
import com.capgemini.paymentwallet.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public interface IPaymentWalletDao {
	public User register (User user) throws PaymentWalletException;
	public boolean login (User user)throws PaymentWalletException;
	public WalletAccount addMoney (BigInteger accId, BigInteger pin,double amount)throws PaymentWalletException;
	public BigDecimal checkBalance (BigInteger accId, BigInteger pin)throws PaymentWalletException; 
	public WalletAccount viewWallet (BigInteger accId, BigInteger pin)throws PaymentWalletException; 
	public  TransactionHistory fundTransfer (BigInteger pin, BigInteger fromAccId, BigInteger toAccId, double amount)throws PaymentWalletException; 
	public List<TransactionHistory> viewtxHistory (BigInteger accId, BigInteger pin, LocalDateTime toDate,  LocalDateTime fromDate)throws PaymentWalletException; 
}
