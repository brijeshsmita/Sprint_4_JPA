/**
 * 
 */
package com.cg.ewallet.rest.services;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ewallet.rest.dao.WalletUserDao;
import com.cg.ewallet.rest.exception.WalletUserException;
import com.cg.ewallet.rest.model.TransactionHistory;
import com.cg.ewallet.rest.model.WalletAccount;
import com.cg.ewallet.rest.model.WalletUser;
import com.cg.ewallet.rest.repository.WalletUserRepository;

/**
 * @author smitkuma
 *
 */
@Service(value = "walletUserService")
public class WalletUserServiceImpl implements WalletUserService {
	// prep work create instance of dao layer
	@Autowired
	private  WalletUserDao walletUserDao;
	@Autowired
	private  WalletUserRepository walletUserRepository;
	@Autowired
	private  TxHistoryService txHistoryService;
	private static Logger myLogger;
	/*
	 * static block to declare logger and create the instance of DaoImpl
	 */

	static {
		setMyLogger(LoggerFactory.getLogger("WalletUserServiceImpl.class"));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.rest.ewallet.rest.services.WalletAccountService#register(com.
	 * capgemini.paymentwallet.model.WalletUser) This is the register method which
	 * create a new user and wallet account *
	 * 
	 * @param walletUser
	 * 
	 * @param accBalance.
	 * 
	 * @return WalletUser.
	 * 
	 * @throws PaymentWalletException
	 */
	@Transactional @Override
	public WalletUser register(WalletUser walletUser, BigDecimal accBalance) throws WalletUserException {
		

		walletUser = walletUserRepository.save(walletUser);
		return walletUser;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.rest.ewallet.rest.services.WalletAccountService#login(com.capgemini
	 * .paymentwallet.model.WalletUser) This is the login method which authenticate
	 * user
	 * 
	 * @param username
	 * 
	 * @param userpass.
	 * 
	 * @return boolean.
	 * 
	 * @throws PaymentWalletException
	 */
	@Transactional @Override
	public boolean login(String username, String userpass) throws WalletUserException {

		boolean status = walletUserDao.login(username, userpass);

		return status;
	}

	/*
	 * This is the findUserById method which search WalletUser by its userId
	 * 
	 * @param userId
	 * 
	 * @return WalletUser.
	 * 
	 * @throws PaymentWalletException
	 */
	@Transactional @Override
	public WalletUser findUserById(Long userId) throws WalletUserException {

		WalletUser walletUser = walletUserRepository.findByUserId(userId);

		return walletUser;
	}

	public  WalletUserDao getPaymentWalletDao() {
		return walletUserDao;
	}

	public  void setPaymentWalletDao(WalletUserDao walletUserDao) {
		this.walletUserDao = walletUserDao;
	}

	/**
	 * @return the myLogger
	 */
	public static Logger getMyLogger() {
		return myLogger;
	}

	/**
	 * @param myLogger the myLogger to set
	 */
	public static void setMyLogger(Logger myLogger) {
		WalletUserServiceImpl.myLogger = myLogger;
	}

}
