/**
 * 
 */

package com.cg.ewallet.rest.controller;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ewallet.rest.exception.WalletUserException;
import com.cg.ewallet.rest.model.TransactionHistory;
import com.cg.ewallet.rest.model.WalletAccount;
import com.cg.ewallet.rest.model.WalletUser;
import com.cg.ewallet.rest.services.TxHistoryService;
import com.cg.ewallet.rest.services.WalletUserService;

/**
 * author: smitkuma Description : Rest controller for WalletUser created Date:
 * 18/10/2019
 */
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/wallet-user")
public class WalletUserRestController {

	@Autowired
	private WalletUserService walletUserService;
	@Autowired
	private	TxHistoryService txHistoryService;
	private static final Logger logger;

	static {
		logger = LoggerFactory.getLogger(WalletUserRestController.class);
	}

	/*
	 * Mapping for the walletUser home page
	 */
//  http://localhost:8082/ewallet-api/wallet-user/
	@GetMapping(value = "/")
	public String displayHomePage(Model model) {
		return "walletUser";
	}
//  http://localhost:8082/ewallet-api/wallet-user/register?confirmPass=sia&accBalance=10000
	@PostMapping(value = "/register", headers = "Accept=application/json")
	public ResponseEntity<WalletUser> registerUser(
			@RequestParam("confirmPass") String confirmPass,
			@RequestParam("accBalance") BigDecimal accBalance, @RequestBody WalletUser walletUser,			Map<String, Object> model) {
		logger.info("**********Testing registerUser**************** "+walletUser);
		logger.info("confirmPass : "+confirmPass);
		logger.info("walletUser.getUserpass() : "+walletUser.getUserpass());

		if (confirmPass.equals(walletUser.getUserpass())) {
			try {
				walletUser.setUserpass(/* bcryptEncoder.encode( */walletUser.getUserpass());
				// Wallet Account
				WalletAccount walletAccount = walletUser.getWalletAccount();
				walletAccount.setAccBalance(accBalance);
				walletAccount.setWalletUser(walletUser);
				walletAccount.setAccOpenDateTime(LocalDateTime.now());
				walletAccount.setWalletUser(walletUser);
				// setting WalletAccount to WalletUser
				walletUser.setWalletAccount(walletAccount);
				List<TransactionHistory> transactionHistories = txHistoryService.addTransactionHistory(walletAccount,
						"Account Open", "Opening the new Wallet Account", accBalance.doubleValue(), 0.0);
				walletAccount.setTransactionHistories(transactionHistories);
				walletUser.setWalletAccount(walletAccount);
				logger.trace(walletUser.getMobileNo() + " got registered");
				walletUser = walletUserService.register(walletUser, accBalance);
				logger.info("walletUser : "+ walletUser);

			} catch (WalletUserException e) {
				logger.error("exception while login....");
				model.put("error", e.getMessage());
				logger.error("Invalid details entered by " + System.getProperties());
				return new ResponseEntity<WalletUser>(HttpStatus.NO_CONTENT);
			}
		} else {
			logger.error("Password Does not match");
			return new ResponseEntity<WalletUser>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<WalletUser>(walletUser, HttpStatus.OK);
	} 
	
//  http://localhost:8082/ewallet-api/wallet-user/login/mona/mona
	@RequestMapping(value = "/login/{username}/{userpass}", headers = "Accept=application/json")
	public ResponseEntity<String> addMoney(@PathVariable String username, 
			@PathVariable String userpass) {
		boolean status = walletUserService.login(username, userpass);
		if (status) {
			return new ResponseEntity<String>(username , HttpStatus.OK);
			
		} else {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
	}
	
//  http://localhost:8082/ewallet-api/wallet-user/view/1
	@GetMapping(value = "/view/{userId}", headers = "Accept=application/json")
	public ResponseEntity<WalletUser> getWalletAccount(@PathVariable Long userId) {
		WalletUser walletUser = walletUserService.findUserById(userId);
		if (walletUser == null) {
			logger.info("User Not Found : "+walletUser);
			return new ResponseEntity<WalletUser>(HttpStatus.NO_CONTENT);
		} else {
			logger.info("User Found : "+walletUser);
			return new ResponseEntity<WalletUser>(walletUser, HttpStatus.OK);
		}
	}
	
	// Getters And Setters 
	public	WalletUserService getWalletUserService() {
		return walletUserService;
	}

	public void setWalletUserService(WalletUserService walletUserService) {
		this.walletUserService = walletUserService;
	}

	public static Logger getLogger() {
		return logger;
	}
}
