package com.cg.ewallet.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ewallet.rest.model.WalletUser;
/** 
 * @author smitkuma
 *
 */
public interface WalletUserRepository extends JpaRepository<WalletUser, Long>{
	
	public WalletUser findByUserId(Long userId);

}
