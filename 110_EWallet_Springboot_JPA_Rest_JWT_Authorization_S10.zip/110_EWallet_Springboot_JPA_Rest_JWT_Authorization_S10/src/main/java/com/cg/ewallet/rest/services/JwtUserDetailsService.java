package com.cg.ewallet.rest.services;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cg.ewallet.rest.dto.UserDto;
import com.cg.ewallet.rest.model.WalletUser;
import com.cg.ewallet.rest.repository.WalletUserRepository;
/**
 * 
 * @author smitkuma
 *
 */

@Service
public class JwtUserDetailsService implements UserDetailsService{
	
	@Autowired
	WalletAccountService walletAccountService;
	@Autowired
	private WalletUserService walletUserService;

	@Autowired
	private WalletUserRepository walletUserRepository;

	@Autowired
	private PasswordEncoder bcryptEncoder;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Optional<WalletUser> walletUser;
		try {
			System.out.println("userName ....loadUserByUsername "+username);
			walletUser = Optional.of(walletUserService.getUserByUserName(username));
			System.out.println("Mobile of User : "+walletUser.get().getMobileNo());
			walletUser.orElseThrow(() -> new UsernameNotFoundException("Not Found: "+username));
			return walletUser.map(com.cg.ewallet.rest.model.WalletUserDetails::new).get();
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		return null;

	}
	
	public WalletUser save(UserDto userDto) {
		WalletUser newUser = new WalletUser();
		newUser.setUsername(userDto.getUsername());
		newUser.setUserpass(bcryptEncoder.encode(userDto.getPassword()));
		return walletUserRepository.save(newUser);
	}
}