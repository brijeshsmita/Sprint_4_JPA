/**
 * 
 */
package com.cg.ewallet.rest.services;

import java.math.BigDecimal;
import java.util.Optional;

import com.cg.ewallet.rest.exception.WalletUserException;
import com.cg.ewallet.rest.model.WalletUser;

/**
 * @author smitkuma
 *
 */
public interface WalletUserService {
	/*	 * This is the register method which create a new user and wallet account	 * 
	 * @param walletUser 
	 * @param accBalance.	 
	 * @return WalletUser.
	 * @throws WalletUserException */
	public WalletUser register (WalletUser walletUser,BigDecimal accBalance) throws WalletUserException;
	/* * This is the login method which authenticate user
	 * @param username 
	 * @param userpass.	 
	 * @return boolean.
	 * @throws WalletUserException */
	public boolean login (String username, String userpass)throws WalletUserException;
	/*
	 * This is the findUserById method which search WalletUser by its userId
	 * @param userId
	 * @return WalletUser.
	 * @throws WalletUserException */
	public WalletUser findUserById(Long userId) throws WalletUserException;
	
	public WalletUser getUserByUserName(String username) throws WalletUserException;
	}
