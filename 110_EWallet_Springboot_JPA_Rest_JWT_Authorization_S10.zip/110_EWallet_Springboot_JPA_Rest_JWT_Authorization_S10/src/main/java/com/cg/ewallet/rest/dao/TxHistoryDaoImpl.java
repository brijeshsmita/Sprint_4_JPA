/**
 * 
 * @throws TxHistoryException */
package com.cg.ewallet.rest.dao;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cg.ewallet.rest.exception.TxHistoryException;
import com.cg.ewallet.rest.model.TransactionHistory;
import com.cg.ewallet.rest.model.WalletAccount;
import com.cg.ewallet.rest.util.ErrorMessageUtil;
import com.cg.ewallet.rest.util.QueryUtil;

/**
 * @author smitkuma
 *
 * @throws TxHistoryException
 */
@Repository(value = "txHistoryDao")
public class TxHistoryDaoImpl implements TxHistoryDao {
	@PersistenceContext
	private EntityManager entityManager;
	private static Logger myLogger;
	/*
	 * static block to declare logger and create the instance of DaoImpl
	 */

	static {
		myLogger = LoggerFactory.getLogger(TxHistoryDaoImpl.class);
	}

	/*
	 * This is the addTransactionHistory method which add current wallet acc tx to
	 * the exiting wallet account tx
	 * 
	 * @param walletAccount
	 * 
	 * @param txType
	 * 
	 * @param txDescription
	 * 
	 * @param amtCredited
	 * 
	 * @param amtDebited
	 * 
	 * @return List<TransactionHistory>.
	 * 
	 * @throws TxHistoryException
	 */
	@Override
	public List<TransactionHistory> addTransactionHistory(WalletAccount walletAccount, String txType,
			String txDescription, double amtCredited, double amtDebited) throws TxHistoryException {
		myLogger.info("-----------addTransactionHistory------------" + walletAccount.getAccId());
		TransactionHistory transactionHistory = new TransactionHistory(walletAccount, LocalDateTime.now(), txType,
				BigDecimal.valueOf(amtCredited), BigDecimal.valueOf(amtDebited), txDescription);
		entityManager.persist(transactionHistory);
		List<TransactionHistory> txHistories = viewAllTxHistory(walletAccount.getAccId());
		return txHistories;
	}

	/*
	 * This is the viewtxHistory method which provide the list of all the tx of the
	 * specific account for specific dates
	 * 
	 * @param accId
	 * 
	 * @param toDate
	 * 
	 * @param fromDate
	 * 
	 * @return List<TransactionHistory>.
	 * 
	 * @throws TxHistoryException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionHistory> viewtxHistory(Long accId, LocalDateTime toDate, LocalDateTime fromDate)
			throws TxHistoryException {
		myLogger.info("-----------viewtxHistory------------");
		List<TransactionHistory> txHistories = new ArrayList<>();
		WalletAccount walletAccount = entityManager.find(WalletAccount.class, accId);
		if (walletAccount != null) {
			Query query = entityManager.createQuery(QueryUtil.VIEW_TX_BY_DATE);
			query.setParameter("walletAccount", walletAccount);
			query.setParameter("toDate", toDate);
			query.setParameter("fromDate", fromDate);
			txHistories = query.getResultList();
			myLogger.info("Tx : " + txHistories);
		} else {
			myLogger.error(ErrorMessageUtil.VIEW_TX_HIS_ERROR);
		}
		return txHistories;
	}
	/*
	 * WalletAccount walletAccount = entityManager.find(WalletAccount.class, accId);
	 * List<TransactionHistory> txHistories = new ArrayList<>();
	 * 
	 * Query query = entityManager.createQuery(QueryUtil.VIEW_TX_HIS);
	 * query.setParameter("walletAccount", walletAccount); txHistories =
	 * query.getResultList(); myLogger.info("Tx : " + txHistories);
	 * List<TransactionHistory> retTxHistories = new
	 * ArrayList<TransactionHistory>(); for (int i = 0; i < txHistories.size(); i++)
	 * { if (txHistories.get(i).getTxDateTime() != null &&
	 * txHistories.get(i).getTxDateTime().compareTo(fromDate) >= 0 &&
	 * txHistories.get(i).getTxDateTime().compareTo(toDate) <= 0) {
	 * retTxHistories.add(txHistories.get(i)); } else {
	 * myLogger.error(ErrorMessageUtil.VIEW_TX_HIS_ERROR); } }
	 */
	

	/*
	 * This is the viewAllTxHistory method which provide the list of all the tx of
	 * the specific account
	 * 
	 * @param accId
	 * 
	 * @return List<TransactionHistory>.
	 * 
	 * @throws TxHistoryException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionHistory> viewAllTxHistory(Long accId) throws TxHistoryException {
		myLogger.info("-----------viewAllTxHistory------------");
		Query query = entityManager.createQuery(QueryUtil.VIEW_TX_HIS);
		query.setParameter("accId", accId);
		List<TransactionHistory> txHistories = query.getResultList();
		myLogger.info("Tx : " + txHistories);

		if (txHistories == null) {
			myLogger.error(ErrorMessageUtil.VIEW_ALL_TX_HIS_ERROR + txHistories);
		}
		return txHistories;
	}
}