/**
 * 
 */
package com.cg.ewallet.rest.dao;

import java.time.LocalDateTime;
import java.util.List;

import com.cg.ewallet.rest.exception.TxHistoryException;
import com.cg.ewallet.rest.model.TransactionHistory;
import com.cg.ewallet.rest.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public interface TxHistoryDao {	
	/*
	 *  This is the viewtxHistory method which provide the list of all the tx of the specific account for specific dates
	 * @param accId
	 * @param toDate
	 * @param fromDate
	 * @return List<TransactionHistory>.
	 * @throws TxHistoryException */
	public List<TransactionHistory> viewtxHistory (Long accId, LocalDateTime toDate,  LocalDateTime fromDate)throws TxHistoryException;
	/*
	 *  This is the viewAllTxHistory method which provide the list of all the tx of the specific account
	 * @param accId
	 * @return List<TransactionHistory>.
	 * @throws TxHistoryException */
	public List<TransactionHistory> viewAllTxHistory(Long accId) throws TxHistoryException;
	/*
	 *  This is the addTransactionHistory method which add current wallet acc tx to the exiting wallet account tx
	 * @param walletAccount
	 * @param txType
	 * @param txDescription
	 * @param amtCredited
	 * @param amtDebited
	 * @return List<TransactionHistory>.
	 * @throws TxHistoryException */
	public List<TransactionHistory> addTransactionHistory(WalletAccount walletAccount, String txType, String txDescription,
			double amtCredited, double amtDebited) throws TxHistoryException; 
}
