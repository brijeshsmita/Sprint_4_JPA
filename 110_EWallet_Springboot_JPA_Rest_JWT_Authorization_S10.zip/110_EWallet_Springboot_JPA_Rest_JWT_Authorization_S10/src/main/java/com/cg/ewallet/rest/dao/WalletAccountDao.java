/**
 * 
 */
package com.cg.ewallet.rest.dao;

import java.math.BigDecimal;

import com.cg.ewallet.rest.exception.PaymentWalletException;
import com.cg.ewallet.rest.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public interface WalletAccountDao {
	
	public WalletAccount addMoney (Long accId, double amount)throws PaymentWalletException;
	/*
	 *  This is the checkBalance method which returns balance form the specific WalletAccount
	 * @param accId
	 * @return BigDecimal.
	 * @throws PaymentWalletException */
	public BigDecimal checkBalance (Long accId)throws PaymentWalletException; 
	/*
	 *  This is the viewWallet method which returns WalletAccount for the specific accId
	 * @param accId
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	public WalletAccount viewWallet (Long accId)throws PaymentWalletException; 
	/*
	 *  This is the viewWalletByUserId method which returns WalletAccount for the specific userId
	 * @param userId
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	public WalletAccount viewWalletByUserId(Long userId) throws PaymentWalletException ;
	/*
	 *  This is the fundTransfer method which transfer amt from 1 WalletAccount to another
	 * @param fromAccId
	 * @param toAccId
	 * @param amount
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	public WalletAccount fundTransfer (Long fromAccId, Long toAccId, double amount)throws PaymentWalletException; 
	
}