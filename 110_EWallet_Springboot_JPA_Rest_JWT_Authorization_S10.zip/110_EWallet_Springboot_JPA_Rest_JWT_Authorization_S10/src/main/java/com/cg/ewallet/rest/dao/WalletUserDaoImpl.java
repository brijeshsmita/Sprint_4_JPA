/**
 * 
 * @throws WalletUserException */
package com.cg.ewallet.rest.dao;

import java.math.BigDecimal;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cg.ewallet.rest.exception.WalletUserException;
import com.cg.ewallet.rest.model.WalletUser;
import com.cg.ewallet.rest.util.QueryUtil;

/**
 * @author smitkuma
 *
 * @throws WalletUserException */
@Repository(value = "walletUserDao")
public class WalletUserDaoImpl implements WalletUserDao {
	@PersistenceContext
	private EntityManager entityManager;
	private static Logger myLogger;
	/*
	 * static block to configure logger and obtain entity manager factory object
	 */
	static {
		myLogger = LoggerFactory.getLogger(WalletUserDaoImpl.class);
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.rest.ewallet.rest.services.WalletAccountService#register(com.
	 * capgemini.paymentwallet.model.WalletUser) 
	 * This is the register method which create a new user and wallet account	  
	 * @param walletUser 
	 * @param accBalance.	 
	 * @return WalletUser.
	 * @throws WalletUserException */
	@Override
	public WalletUser register(WalletUser walletUser, BigDecimal accBalance) throws WalletUserException {
		myLogger.info("-----------register------------");
		entityManager.persist(walletUser);
		return walletUser;

	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.rest.ewallet.rest.services.WalletAccountService#login(com.
	 * capgemini.paymentwallet.model.WalletUser)
	 * This is the login method which authenticate user
	 * @param username 
	 * @param userpass.	 
	 * @return boolean.
	 * @throws WalletUserException */
	@Override
	public boolean login(String username, String userpass) throws WalletUserException {
		myLogger.info("-----------login------------");
		boolean status = false;
		Query query = entityManager.createQuery(QueryUtil.CHECK_LOGIN);
		// setting the query dynamic parameter
		query.setParameter("uname", username);
		query.setParameter("upass", userpass);
		// fetching only 1 result
		query.setMaxResults(1);
		WalletUser walletUser = (WalletUser) query.getSingleResult();
		myLogger.info(" WalletUser login ..... " + walletUser);
		if (walletUser != null) {
			status = true;
			myLogger.info(" WalletUser login successful!! " + walletUser);
		}
		else {
			status = true;
			myLogger.error(" WalletUser login failed!! " + walletUser);
		}
		return status;
	}

	/*
	 * This is the findUserById method which search WalletUser by its userId
	 * @param userId
	 * @return WalletUser.
	 * @throws WalletUserException */
	@Override
	public WalletUser findUserById(Long userId) throws WalletUserException {
		myLogger.info("-----------findUserById------------");
		WalletUser 	walletUser = entityManager.find(WalletUser.class, userId);	
		if (walletUser != null) {
			myLogger.error(" WalletUser findUserById is null..userId:"+userId+".. " + walletUser);
		}
		myLogger.info(" WalletUser findUserById is found with..userId:"+userId+".. " + walletUser);
		return walletUser;
	}

	@Override
	public WalletUser findUserByUserName(String username) throws WalletUserException {
		myLogger.info("-----------findUserByUserName------------");
		Query query = entityManager.createQuery(QueryUtil.CHECK_USERNAME);
		// setting the query dynamic parameter
		query.setParameter("uname", username);
		// fetching only 1 result
		query.setMaxResults(1);
		WalletUser walletUser = (WalletUser) query.getSingleResult();
		myLogger.info(" WalletUser  ..... " + walletUser);
		if (walletUser != null) {
			myLogger.info(" WalletUser login successful!! " + walletUser);
		}
		else {
			myLogger.error(" WalletUser login failed!! " + walletUser);
		}
		return walletUser;
	}
}