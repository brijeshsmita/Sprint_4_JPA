package com.cg.ewallet.rest.dto;

/**
 * 
 * @author smitkuma
 *
 */
public class UserDto {

	private String username;
	private String userPassword;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return userPassword;
	}

	public void setPassword(String password) {
		this.userPassword = password;
	}
}