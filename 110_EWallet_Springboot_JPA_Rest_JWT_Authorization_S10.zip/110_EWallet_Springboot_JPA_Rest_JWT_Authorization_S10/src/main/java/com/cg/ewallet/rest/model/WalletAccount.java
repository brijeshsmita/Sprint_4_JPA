/**
 * 
 */
package com.cg.ewallet.rest.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

/**
 * @author smitkuma
 *'1', '1001', '2019-11-07 14:46:48', 'Add Money', '1000', '0', 'Add Money to Wallet'
 *'91', NULL, '2019-11-11 16:19:29', 'Fund transfer', '50', '0', 'Fund transfered from 1001'


 */
@Entity
@Table(name="WALLET_ACCOUNT")
public class WalletAccount implements Serializable{
	private static final long serialVersionUID = -3946091634178111941L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ACC_ID")
	@Id
	private Long accId;	
	@JsonManagedReference
	@OneToOne(cascade = CascadeType.ALL,mappedBy = "walletAccount")
	private WalletUser walletUser;
	
	@Column(name="ACC_BALANCE")
	private BigDecimal accBalance;
	
	@Column(name="ACC_OPEN_DATETIME", nullable = false)
	//@Temporal(TemporalType.TIMESTAMP)
	//@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDateTime accOpenDateTime ;
	
	@Enumerated(EnumType.STRING)
	@Column(name="WALLET_ACC_STATUS", nullable = false)
	private WalletAccStatus walletAccStatus;
	/*
	 * Note that:

	@JsonManagedReference is the forward part of reference – the one that gets serialized normally.
	@JsonBackReference is the back part of reference – it will be omitted from serialization.
	 */	
	@JsonManagedReference
	@OneToMany(mappedBy = "walletAccount",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<TransactionHistory> transactionHistories;
   
    //INITIALIZER BLOCK
    {
		this.walletAccStatus=WalletAccStatus.PENDING;
		this.transactionHistories=new ArrayList<TransactionHistory>(0);
    }
	public WalletAccount(WalletUser walletUser, BigDecimal accBalance, LocalDateTime accOpenDateTime,
			List<TransactionHistory> transactionHistories) {
		super();
		this.walletUser = walletUser;
		this.accBalance = accBalance;
		this.accOpenDateTime = accOpenDateTime;
		this.transactionHistories = transactionHistories;
	}
	@Override
	public String toString() {
		return "WalletAccount [accId=" + accId + ", accBalance=" + accBalance + ", accOpenDateTime=" + accOpenDateTime
				+ ", walletAccStatus=" + walletAccStatus + ", transactionHistories=" + transactionHistories + "]";
	}

	public WalletAccount() {
		// TODO Auto-generated constructor stub
	}

	public Long getAccId() {
		return accId;
	}

	public void setAccId(Long accId) {
		this.accId = accId;
	}

	public WalletUser getWalletUser() {
		return walletUser;
	}

	public void setWalletUser(WalletUser walletUser) {
		this.walletUser = walletUser;
	}

	public BigDecimal getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(BigDecimal accBalance) {
		this.accBalance = accBalance;
	}

	public LocalDateTime getAccOpenDateTime() {
		return accOpenDateTime;
	}

	public void setAccOpenDateTime(LocalDateTime accOpenDateTime) {
		this.accOpenDateTime = accOpenDateTime;
	}

	public List<TransactionHistory> getTransactionHistories() {
		return transactionHistories;
	}

	public void setTransactionHistories(List<TransactionHistory> transactionHistories) {
		this.transactionHistories = transactionHistories;
	}

	@Override
	public int hashCode() {		
		return this.accId.intValue();
	}

	@Override
	public boolean equals(Object obj) {
		boolean status= false;
		if(obj!=null)
			status= this.hashCode()==obj.hashCode();
		return status;
	}
}
