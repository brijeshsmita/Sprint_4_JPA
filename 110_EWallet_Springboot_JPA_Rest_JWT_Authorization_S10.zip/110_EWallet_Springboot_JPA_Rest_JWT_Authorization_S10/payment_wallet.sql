CREATE DATABASE IF NOT EXISTS payment_wallet_db; 	

USE payment_wallet_db;
DROP TABLE Transaction_History;
DROP TABLE wallet_user;
DROP TABLE wallet_account;


CREATE TABLE IF NOT EXISTS  wallet_account 
	(
		acc_Id bigint AUTO_INCREMENT,
		acc_Balance double,
		acc_Open_DateTime TIMESTAMP,
		WALLET_ACC_STATUS varchar(10) NOT NULL ,
		  CONSTRAINT pk_wallet_account PRIMARY KEY  (acc_Id)	 
		
	);
	ALTER TABLE wallet_account AUTO_INCREMENT = 1001;
	
	insert into wallet_account(acc_Balance,acc_Open_DateTime,WALLET_ACC_STATUS) values(1000.0,NOW(),'APPROVED');
	insert into wallet_account(acc_Balance,acc_Open_DateTime,WALLET_ACC_STATUS) values(1000.0,NOW(),'APPROVED');
	commit;
	select * from wallet_account where acc_id=1001;
	select * from wallet_account;
	CREATE TABLE IF NOT EXISTS wallet_user 
	(
		user_id bigint AUTO_INCREMENT,
		acc_Id bigint,
		username varchar(50) NOT NULL ,
		userpass varchar(50) NOT NULL ,
		pin bigint NOT NULL,
		first_name varchar(50) NOT NULL ,
		last_name varchar(50) NOT NULL ,
		mobile_no bigint NOT NULL ,
		address varchar(200) NOT NULL ,
		email varchar(80) NOT NULL ,
		roles varchar(10) NOT NULL ,
		CONSTRAINT pk_wallet_user PRIMARY KEY(user_id),
		 FOREIGN KEY fk_wallet_account(acc_Id) REFERENCES wallet_account(acc_Id)	
	);
	
	ALTER TABLE wallet_user AUTO_INCREMENT = 1;
	
	insert into wallet_user(acc_Id,username,userpass,pin,first_name,last_name,mobile_no,address,email,roles) 
    values(1001,'mona','mona',1234,'Mona','Gupta',9870006622,'Mumbai','urmona@yahoo.com','admin');
	insert into wallet_user(acc_Id,username,userpass,pin,first_name,last_name,mobile_no,address,email,roles) 
	values(1002,'sia','sia',1234,'Sia','Gupta',9876543210,'Pune','pihusia@gmail.com','user');

	select * from wallet_user;
	
	
	
	CREATE TABLE IF NOT EXISTS  Transaction_History (
		tx_Id bigint AUTO_INCREMENT,
		acc_Id bigint,
		tx_Date_Time TIMESTAMP,
		tx_Type varchar(20) NOT NULL,
		amt_Credited double ,
		amt_Debited double ,
		tx_Description varchar(200) NOT NULL,
		CONSTRAINT pk_Transaction_History PRIMARY KEY  (tx_Id),
		FOREIGN KEY fk_acc_id(acc_Id) REFERENCES wallet_account(acc_Id)	
	);
	
	insert into Transaction_History(acc_Id,tx_Date_Time,tx_Type,amt_Credited,amt_Debited,tx_Description) values(1001,NOW(),'Add Money',1000.00,0.0,'Add Money to Wallet');
	insert into Transaction_History(acc_Id,tx_Date_Time,tx_Type,amt_Credited,amt_Debited,tx_Description) values(1002,NOW(),'Add Money',1000.00,0.0,'Add Money to Wallet');
	
	select * from Transaction_History;
	
	select * from Transaction_History where acc_id=1027 and tx_Date_Time between '2019-11-11 00:00:00' and NOW();
	
	