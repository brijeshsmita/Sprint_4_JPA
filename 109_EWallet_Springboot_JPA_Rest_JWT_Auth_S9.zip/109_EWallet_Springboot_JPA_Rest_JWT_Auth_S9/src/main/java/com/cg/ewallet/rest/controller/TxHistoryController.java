/**
 * 
 */

package com.cg.ewallet.rest.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ewallet.rest.model.TransactionHistory;
import com.cg.ewallet.rest.services.TxHistoryService;

/**
 * author: smitkuma Description : Rest controller for WalletUser created Date:
 * 18/10/2019 Controller with different HTTP methods as GET,POST,DELETE and
 * their respective URL mappings class level request mapping as "txHistory"
 * return type is JSON
 */
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/txHistory")
public class TxHistoryController {
	private static final Logger logger;
	static {
		logger = LoggerFactory.getLogger(TxHistoryController.class);
	}

	@Autowired
	private	TxHistoryService txHistoryService;

	/*
	 * Mapping for the TxHistory home page
	 */
//  http://localhost:8082/ewallet-api/txHistory/
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String displayHomePage(Model model) {
		return "walletUser";
	}
//  http://localhost:8082/ewallet-api/txHistory/search-bydate/1001/2019-11-07 14:46:48/2019-11-11 16:19:29
	@RequestMapping(value = "/search-bydate/{accId}/{toDate}/{fromDate}", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<List<TransactionHistory>> viewTxHistoryByDate(@PathVariable Long accId,

			@PathVariable String toDate, @PathVariable String fromDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime toLocalDate = LocalDateTime.parse(toDate, formatter);
		LocalDateTime fromLocalDate = LocalDateTime.parse(fromDate, formatter);
		List<TransactionHistory> testList = txHistoryService.viewtxHistory(accId, toLocalDate, fromLocalDate);
		if (testList == null) {
			return new ResponseEntity<List<TransactionHistory>>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<List<TransactionHistory>>(testList, HttpStatus.OK);
		}
	}

	/*
	 * Mapping for
	 * 
	 * the table to display all tx by accId
	 */
//	http://localhost:8082/ewallet-api/txHistory/search/1001
	@RequestMapping(value="/search/{accId}",method=RequestMethod.GET)
	public ResponseEntity<List<TransactionHistory>> viewTxHistoryById(@PathVariable Long accId) {
		List<TransactionHistory> testList = txHistoryService.viewAllTxHistory(accId);
		if (testList == null) {
			return new ResponseEntity<List<TransactionHistory>>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<List<TransactionHistory>>(testList, HttpStatus.OK);
		}
	} // Getters And Setters

	public static Logger getLogger() {
		return logger;
	}
}
