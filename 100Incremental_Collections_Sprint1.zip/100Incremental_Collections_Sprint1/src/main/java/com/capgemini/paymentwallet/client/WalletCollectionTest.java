/**
 * 
 */
package com.capgemini.paymentwallet.client;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.paymentwallet.dao.IPaymentWalletDao;
import com.capgemini.paymentwallet.dao.PaymentWalletDao;
import com.capgemini.paymentwallet.dao.UserDb;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.User;
import com.capgemini.paymentwallet.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public class WalletCollectionTest {
	private static IPaymentWalletDao paymentWalletDao;
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		paymentWalletDao=new PaymentWalletDao();
	}
	@Test
	public void testUserDb() throws PaymentWalletException {
		List<User> users=UserDb.getUsers();
		assertNotNull("No Users DB Exists !!!", users);
		users.forEach(System.out::println);
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#addMoney(java.lang.Long, java.lang.Integer, java.lang.Double)}.
	 * @throws PaymentWalletException 
	 */
	@Test
	public void testAddMoney() throws PaymentWalletException {
		WalletAccount walletAccount=paymentWalletDao.addMoney(1001L, 1234, 1000.00);
		assertNotNull("Account Does Not exists", walletAccount);
		System.out.println(" walletAccount "+walletAccount);
	/*WalletAccount walletAccount1= new WalletAccount();
		User u1 = new User("mona", "mona", 1234, "Mona", "Gupta", "987000662", "Mumbai");
		walletAccount1.setAccBalance(1000.00);
		walletAccount1.setUser(u1);
		u1.setWalletAccount(walletAccount1);*/	
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#checkBalance(java.lang.Long, java.lang.Integer)}.
	 * @throws PaymentWalletException 
	 */
	@Test
	public void testCheckBalance() throws PaymentWalletException {
		Double actual=1000.00;
		Double accBalance=paymentWalletDao.checkBalance(1002L, 1234);
		assertEquals(actual,accBalance);
		System.out.println(" walletAccount Balance of acc 1002 is "+accBalance);
		
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#viewWallet(java.lang.Long, java.lang.Integer)}.
	 * @throws PaymentWalletException 
	 */
	@Test
	public void testViewWallet() throws PaymentWalletException {
		
		WalletAccount walletAccount=paymentWalletDao.viewWallet(1001L, 1234);
		assertNotNull("Account Does Not exists", walletAccount);
		System.out.println(" walletAccount "+walletAccount);
		
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#fundTransfer(java.lang.Integer, java.lang.Long, java.lang.Long, java.lang.Double)}.
	 * @throws PaymentWalletException 
	 */
	@Test
	public void testFundTransfer() throws PaymentWalletException {
		TransactionHistory transactionHistory=paymentWalletDao.fundTransfer(1234, 1001L, 1002L, 200.00);
		assertNotNull("Transaction not happened", transactionHistory);
		System.out.println(" transactionHistory "+transactionHistory);
	}

}
