/**
 * 
 */
package com.capgemini.paymentwallet.services;

import java.time.LocalDateTime;
import java.util.List;

import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.User;
import com.capgemini.paymentwallet.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public interface IPaymentWalletService {
	public User register (User user) throws PaymentWalletException;
	public boolean login (User user)throws PaymentWalletException;
	public WalletAccount addMoney (Long accId, Integer pin,Double amount)throws PaymentWalletException;
	public double checkBalance (Long accId, Integer pin)throws PaymentWalletException; 
	public WalletAccount viewWallet (Long accId, Integer pin)throws PaymentWalletException; 
	public  TransactionHistory fundTransfer (Integer pin, Long fromAccId, Long toAccId, Double amount)throws PaymentWalletException; 
	public List<TransactionHistory> viewtxHistory (Long accId, Integer pin, LocalDateTime toDate,  LocalDateTime fromDate)throws PaymentWalletException; 
}
