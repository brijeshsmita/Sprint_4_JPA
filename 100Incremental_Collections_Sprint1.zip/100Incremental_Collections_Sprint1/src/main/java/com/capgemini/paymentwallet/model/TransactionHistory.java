/**
 * 
 */
package com.capgemini.paymentwallet.model;

import java.time.LocalDateTime;

/**
 * @author smitkuma
 *
 */
public class TransactionHistory {
	 private Long txId;
	 private WalletAccount walletAccount;
	 private LocalDateTime txDateTime ;
	 private String txType ; 
	 private Double amtCredited ; 
	 private Double amtDebited ; 
	 private String txDescription ;
	 
	 private static Long numId;
	//static initializer block
		static {
			//for auto-generating userId
			numId= (long) (10+ (Math.random()*12.12));
		}
		//initializer block
		{
			txId= numId++;
		}
		public TransactionHistory() {
			// TODO Auto-generated constructor stub
		}
		public TransactionHistory(WalletAccount walletAccount, LocalDateTime txDateTime, String txType,
				Double amtCredited, Double amtDebited, String txDescription) {
			super();
			this.walletAccount = walletAccount;
			this.txDateTime = txDateTime;
			this.txType = txType;
			this.amtCredited = amtCredited;
			this.amtDebited = amtDebited;
			this.txDescription = txDescription;
		}
		public Long getTxId() {
			return txId;
		}
		public void setTxId(Long txId) {
			this.txId = txId;
		}
		public WalletAccount getWalletAccount() {
			return walletAccount;
		}
		public void setWalletAccount(WalletAccount walletAccount) {
			this.walletAccount = walletAccount;
		}
		public LocalDateTime getTxDateTime() {
			return txDateTime;
		}
		public void setTxDateTime(LocalDateTime txDateTime) {
			this.txDateTime = txDateTime;
		}
		public String getTxType() {
			return txType;
		}
		public void setTxType(String txType) {
			this.txType = txType;
		}
		public Double getAmtCredited() {
			return amtCredited;
		}
		public void setAmtCredited(Double amtCredited) {
			this.amtCredited = amtCredited;
		}
		public Double getAmtDebited() {
			return amtDebited;
		}
		public void setAmtDebited(Double amtDebited) {
			this.amtDebited = amtDebited;
		}
		public String getTxDescription() {
			return txDescription;
		}
		public void setTxDescription(String txDescription) {
			this.txDescription = txDescription;
		}
		@Override
		public String toString() {
			return "TransactionHistory [txId=" + txId + ", walletAccount=" + walletAccount + ", txDateTime="
					+ txDateTime + ", txType=" + txType + ", amtCredited=" + amtCredited + ", amtDebited=" + amtDebited
					+ ", txDescription=" + txDescription + "]";
		}
}
