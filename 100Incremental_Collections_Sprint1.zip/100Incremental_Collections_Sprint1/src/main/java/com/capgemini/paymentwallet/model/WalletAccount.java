/**
 * 
 */
package com.capgemini.paymentwallet.model;

import java.util.List;

/**
 * @author smitkuma
 *
 */
public class WalletAccount {
	private Long accId;
	private User user;
	private Double accBalance;
	private static Long numId;
	private List<TransactionHistory> transactionHistories;
	//static initializer block
	static {
		//for auto-generating userId
		numId= (long) (1000000+ (Math.random()*123456.123456));
	}
	//initializer block
	{
		accId= numId++;
	}
	public WalletAccount(Double accBalance, User user) {
		super();
		this.accBalance = accBalance;
		this.user = user;
	}
	public WalletAccount() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "WalletAccount [accId=" + accId + ", accBalance=" + accBalance + "]";
	}
	public Long getAccId() {
		return accId;
	}
	public void setAccId(Long accId) {
		this.accId = accId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Double getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(Double accBalance) {
		this.accBalance = accBalance;
	}
	public List<TransactionHistory> getTransactionHistories() {
		return transactionHistories;
	}
	public void setTransactionHistories(List<TransactionHistory> transactionHistories) {
		this.transactionHistories = transactionHistories;
	}
}
