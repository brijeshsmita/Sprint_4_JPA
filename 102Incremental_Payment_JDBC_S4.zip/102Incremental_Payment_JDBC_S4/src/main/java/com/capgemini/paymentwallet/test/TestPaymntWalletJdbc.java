/**
 * 
 */
package com.capgemini.paymentwallet.test;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.paymentwallet.dao.PaymentWalletDao;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.services.PaymentWalletService;

/**
 * @author smitkuma
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TestPaymntWalletJdbc {

	@InjectMocks
	PaymentWalletService paymentWalletService;

	@Mock
	PaymentWalletDao paymentWalletDao;
	
	BigInteger userId;
	BigInteger accId;
	BigInteger txId;
	WalletUser walletUser;

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#register(com.capgemini.paymentwallet.model.WalletUser, java.math.BigDecimal)}.
	 * @throws PaymentWalletException 
	 */
	@Test	
	public void testRegister() throws PaymentWalletException {
		WalletAccount walletAccount= new WalletAccount();
		walletUser = new WalletUser("mona", "mona", BigInteger.valueOf(1234), "Mona", "Sen", new BigInteger("9870003333"), "Mumbai");
		walletUser.setWalletAccount(walletAccount);
		WalletUser registeredUser=paymentWalletService.register(walletUser,BigDecimal.valueOf(5000.00));
		assertNotNull("User Not Registered!! ", registeredUser);
		System.out.println("Registered User : "+registeredUser);
		userId=walletUser.getUserId();
		accId=walletUser.getWalletAccount().getAccId();
	
	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#login(java.lang.String, java.lang.String)}.
	 * @throws PaymentWalletException 
	 */
	@Test
	public void testLogin() throws PaymentWalletException {
		boolean status=paymentWalletService.login("mona", "mona");
		assertEquals(status, true);
		System.out.println("Login status : "+status);
	
	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#addMoney(java.math.BigInteger, double)}.
	 * @throws PaymentWalletException 
	 */
	@Test
	public void testAddMoney() throws PaymentWalletException {
		System.out.println("**** testAddMoney***************");
	/*	BigInteger fromUserId=walletUser.getUserId();
		WalletUser fromFoundUser=paymentWalletDao.findUserById(fromUserId);
		System.out.println("fromFoundUser : "+fromFoundUser);
		*/
		//add money to walletAccount 1
		//BigInteger fromAccId= fromFoundUser.getWalletAccount().getAccId();
		WalletAccount updatedWalletAcc =paymentWalletDao.addMoney(BigInteger.valueOf(1021), 2000.00);
		System.out.println("**** After AddMony updatedWalletAcc : "+updatedWalletAcc);
		
		assertNotNull("Money Not Added to WalletAccount !! "+1009, updatedWalletAcc);
	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#checkBalance(java.math.BigInteger)}.
	 */
	@Test
	public void testCheckBalance() {

	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#viewWallet(java.math.BigInteger)}.
	 */
	@Test
	public void testViewWallet() {

	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#fundTransfer(java.math.BigInteger, java.math.BigInteger, double)}.
	 */
	@Test
	public void testFundTransfer() {

	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#viewtxHistory(java.math.BigInteger, java.time.LocalDateTime, java.time.LocalDateTime)}.
	 */
	@Test
	public void testViewtxHistory() {

	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#getPaymentWalletDao()}.
	 */
	@Test
	public void testGetPaymentWalletDao() {

	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#setPaymentWalletDao(com.capgemini.paymentwallet.dao.IPaymentWalletDao)}.
	 */
	@Test
	public void testSetPaymentWalletDao() {

	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.PaymentWalletService#findUserById(java.math.BigInteger)}.
	 */
	@Test
	public void testFindUserById() {

	}

}
