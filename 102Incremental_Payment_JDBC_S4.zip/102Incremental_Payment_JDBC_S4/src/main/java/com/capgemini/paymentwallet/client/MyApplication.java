/*package com.cg.employeemanagement.ui;

import java.util.Scanner;

import com.cg.employeemanagement.dto.Department;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.service.EmployeeService;
import com.cg.employeemanagement.service.EmployeeServiceImpl;

public class MyApplication {
	
	public static void main(String args[]) {
		
		EmployeeService service=new EmployeeServiceImpl();
		
		
		Scanner scr=new Scanner(System.in);
		char A='n';
		
		do {
				System.out.println("enter the Employee ID");
				int id=scr.nextInt();
		
				
				System.out.println("enter Employee name");
				String name=scr.next();
				
				System.out.println("Enter Employee Salary");
				double sal=scr.nextDouble();
				
				System.out.println("enter Employee Department Id");
				int did=scr.nextInt();
				
				System.out.println("Enter Employee Department Name");
				String dname=scr.next();
				
				Department dep=new Department();
				dep.setDeptId(did);
				dep.setDeptName(dname);
				
				Employee emp=new Employee();
				emp.setEmpId(id);
				emp.setEmpName(name);
				emp.setEmpSalary(sal);
				emp.setDepartment(dep);
				
				service.addEmployee(emp);
				
				System.out.println("press y to add employee... ");
				A=scr.next().charAt(0);
				}while(A=='y');
				Employee empArray[]=service.showEmployee();
				
				for(int i=0;i<empArray.length;i++) {
					if(i==0) {
						System.out.println("Employee Name is "+empArray[i].getEmpName());
					}
				}
				
				
				
				
				
	}

}
*/