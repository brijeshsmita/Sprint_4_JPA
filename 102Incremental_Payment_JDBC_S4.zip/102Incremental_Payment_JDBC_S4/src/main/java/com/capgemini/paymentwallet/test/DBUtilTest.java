/**
 * 
 */
package com.capgemini.paymentwallet.test;

import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.jupiter.api.BeforeAll;

import com.capgemini.paymentwallet.dao.DBUtil;
import com.capgemini.paymentwallet.exception.PaymentWalletException;

/**
 * @author smitkuma
 *
 */
public class DBUtilTest {
	// testing connection before class
	private static Connection connection;

		@BeforeAll
		public static void testGetConnection() throws PaymentWalletException {
			connection = DBUtil.getConnection();
			assertNotNull(connection);
			System.out.println(" DBUtilTest :" +connection);
		}

}
