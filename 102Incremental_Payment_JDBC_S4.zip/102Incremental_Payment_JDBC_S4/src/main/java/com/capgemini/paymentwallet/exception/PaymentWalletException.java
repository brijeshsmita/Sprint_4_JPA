/**
 * 
 */
package com.capgemini.paymentwallet.exception;

/**
 * @author smitkuma
 *
 */
public class PaymentWalletException extends Exception {

	public PaymentWalletException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PaymentWalletException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -7900677380899033365L;

}
