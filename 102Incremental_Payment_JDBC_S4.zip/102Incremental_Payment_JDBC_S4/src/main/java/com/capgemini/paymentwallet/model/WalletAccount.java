/**
 * 
 */
package com.capgemini.paymentwallet.model;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author smitkuma
 *
 */
public class WalletAccount {
	private BigInteger accId;
	private WalletUser walletUser;
	private BigDecimal accBalance;
	private LocalDateTime accOpenDateTime ;
	private static long numId;
	private List<TransactionHistory> transactionHistories;
	//static initializer block
	static {
		//for auto-generating userId
		numId= (long) (1000000+ (Math.random()*123456.123456));
	}
	//initializer block
	{
		accId= BigInteger.valueOf(numId++);
	}
	
	public WalletAccount(BigInteger accId, WalletUser walletUser, BigDecimal accBalance, LocalDateTime accOpenDateTime) {
		super();
		this.accId = accId;
		this.walletUser = walletUser;
		this.accBalance = accBalance;
		this.accOpenDateTime = accOpenDateTime;
	}

	public WalletAccount() {
		// TODO Auto-generated constructor stub
	}

	public BigInteger getAccId() {
		return accId;
	}

	public void setAccId(BigInteger accId) {
		this.accId = accId;
	}

	public WalletUser getWalletUser() {
		return walletUser;
	}

	public void setWalletUser(WalletUser walletUser) {
		this.walletUser = walletUser;
	}

	public BigDecimal getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(BigDecimal accBalance) {
		this.accBalance = accBalance;
	}

	public LocalDateTime getAccOpenDateTime() {
		return accOpenDateTime;
	}

	public void setAccOpenDateTime(LocalDateTime accOpenDateTime) {
		this.accOpenDateTime = accOpenDateTime;
	}

	public List<TransactionHistory> getTransactionHistories() {
		return transactionHistories;
	}

	public void setTransactionHistories(List<TransactionHistory> transactionHistories) {
		this.transactionHistories = transactionHistories;
	}

	@Override
	public String toString() {
		return "WalletAccount [accId=" + accId + ", accBalance=" + accBalance
				+ ", accOpenDateTime=" + accOpenDateTime + ", transactionHistories=" + transactionHistories + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accBalance == null) ? 0 : accBalance.hashCode());
		result = prime * result + ((accId == null) ? 0 : accId.hashCode());
		result = prime * result + ((accOpenDateTime == null) ? 0 : accOpenDateTime.hashCode());
		result = prime * result + ((transactionHistories == null) ? 0 : transactionHistories.hashCode());
		result = prime * result + ((walletUser == null) ? 0 : walletUser.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WalletAccount other = (WalletAccount) obj;
		if (accBalance == null) {
			if (other.accBalance != null)
				return false;
		} else if (!accBalance.equals(other.accBalance))
			return false;
		if (accId == null) {
			if (other.accId != null)
				return false;
		} else if (!accId.equals(other.accId))
			return false;
		if (accOpenDateTime == null) {
			if (other.accOpenDateTime != null)
				return false;
		} else if (!accOpenDateTime.equals(other.accOpenDateTime))
			return false;
		if (transactionHistories == null) {
			if (other.transactionHistories != null)
				return false;
		} else if (!transactionHistories.equals(other.transactionHistories))
			return false;
		if (walletUser == null) {
			if (other.walletUser != null)
				return false;
		} else if (!walletUser.equals(other.walletUser))
			return false;
		return true;
	}
}
