/**
 * 
 */
package com.capgemini.paymentwallet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author Smita B Kumar
 *
 */
public class ConnectionUtil {
	private static Connection connection;

	public static Connection getConnection() {
		//String url="jdbc:oracle:thin:@localhost:1521:orahome";
		String url ="jdbc:mysql://localhost:3306";
		String user="root";
		String password="root";		
		try {
			connection=DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			System.out.println("exception while connecting to DB "+e.getMessage());
		}
		return connection;
	}
	public static void main(String[] args) {
		System.out.println("Connection : "+ConnectionUtil.getConnection());
	}
}







