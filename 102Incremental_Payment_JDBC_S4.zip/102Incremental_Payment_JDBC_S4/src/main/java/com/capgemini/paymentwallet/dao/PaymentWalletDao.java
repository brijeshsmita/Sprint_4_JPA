/**
 * 
 */
package com.capgemini.paymentwallet.dao;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;

import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.model.WalletAccount;
import java.sql.*;

/**
 * @author smitkuma
 *
 */
public class PaymentWalletDao implements IPaymentWalletDao {
	private static Connection connection;
	private PreparedStatement ps;
	private PreparedStatement ps1;
	private PreparedStatement ps2;
	private ResultSet rs;

	static {
		try {
			connection = DBUtil.getConnection();
		} catch (PaymentWalletException e) {
			System.out.println("connection Not Obatined at PaymentWalletDao : " + connection);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#register(com.
	 * capgemini.paymentwallet.model.WalletUser)
	 */
	@Override
	public WalletUser register(WalletUser walletUser, BigDecimal accBalance) throws PaymentWalletException {
		System.out.println("-----------register------------");
		String sql_user = "insert into wallet_user(username,password,pin,first_name,last_name,mobile_no,address) values(?,?,?,?,?,?,?)";
		try {
			// tx boundaries
			connection.setAutoCommit(false);
			ps = connection.prepareStatement(sql_user, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, walletUser.getUsername());
			ps.setString(2, walletUser.getPassword());
			ps.setString(3, String.valueOf(walletUser.getPin()));
			ps.setString(4, walletUser.getFirstName());
			ps.setString(5, walletUser.getLastName());
			ps.setString(6, String.valueOf(walletUser.getMobileNo()));
			ps.setString(7, walletUser.getAddress());
			ps.executeUpdate();// insert to wallet_user
			// getting auto-generated id
			BigInteger generatedUserId = BigInteger.valueOf(0L);
			rs = ps.getGeneratedKeys();
			if (rs.next()) {
				generatedUserId = BigInteger.valueOf(rs.getLong(1));
				// System.out.println("Auto generatedUserId " + generatedUserId);
			}
			walletUser.setUserId(generatedUserId); // setting auto-genrated id

			// insert WallletAccout
			WalletAccount walletAccount = addWalletAccount(walletUser, accBalance);
			System.out.println("Payment Wallet updated : " + walletAccount);
			// insert TransactionHistory
			TransactionHistory txHistory = addTransactionHistory(walletAccount, "Account Open",
					" Register For Wallet Account", accBalance, BigDecimal.ZERO);
			txHistory.setWalletAccount(walletAccount);
			System.out.println("Transaction updated : " + txHistory);
			List<TransactionHistory> transactionHistories = viewAllTxHistory(walletAccount.getAccId());
			walletAccount.setTransactionHistories(transactionHistories);

			walletUser.setWalletAccount(walletAccount);
			connection.commit();
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao register method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
					connection.rollback();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao register method : " + e);
				}
			}
		}
		return walletUser;// if user added successfully then return user object else return null
	}

	public WalletAccount addWalletAccount(WalletUser walletUser, BigDecimal accBalance) throws PaymentWalletException {
		System.out.println("-----------addWalletAccount------------");
		String sql_wallet = "insert into wallet_account(user_id,acc_Balance,acc_Open_DateTime) values(?,?,?)";
		WalletAccount walletAccount = walletUser.getWalletAccount();
		LocalDateTime accOpenDateTime = LocalDateTime.now();
		try {
			ps1 = connection.prepareStatement(sql_wallet, Statement.RETURN_GENERATED_KEYS);
			ps1.setString(1, String.valueOf(walletUser.getUserId()));
			ps1.setBigDecimal(2, accBalance);
			ps1.setDate(3, java.sql.Date.valueOf(accOpenDateTime.toLocalDate()));
			ps1.executeUpdate();// insert to wallet_account
			// getting auto-generated id
			BigInteger walletAccId = BigInteger.valueOf(0L);
			rs = ps1.getGeneratedKeys();
			if (rs.next()) {
				walletAccId = BigInteger.valueOf(rs.getLong(1));
				// System.out.println("Auto Generated walletAccId " + walletAccId);
			}
			walletAccount.setAccId(walletAccId);
			walletAccount.setAccBalance(accBalance);
			walletAccount.setWalletUser(walletUser);
			walletAccount.setAccOpenDateTime(accOpenDateTime);
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao register method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao register method : " + e);
				}
			}
		}
		return walletAccount;
	}

	public TransactionHistory addTransactionHistory(WalletAccount walletAccount, String txType, String txDescription,
			BigDecimal amtCredited, BigDecimal amtDebited) throws PaymentWalletException {
		System.out.println("-----------addTransactionHistory------------");
		String sql_tx = "insert into Transaction_History(acc_Id,tx_Date_Time,tx_Type,amt_Credited,amt_Debited,tx_Description) values(?,?,?,?,?,?)";
		TransactionHistory txHistory = new TransactionHistory();
		LocalDateTime txDateTime = LocalDateTime.now();
		try {
			ps2 = connection.prepareStatement(sql_tx, Statement.RETURN_GENERATED_KEYS);
			ps2.setString(1, String.valueOf(walletAccount.getAccId()));
			ps2.setDate(2, java.sql.Date.valueOf(txDateTime.toLocalDate()));// convert sql date to localDateTime
			ps2.setString(3, txType);
			ps2.setBigDecimal(4, amtCredited);
			ps2.setBigDecimal(5, amtDebited);
			ps2.setString(6, txDescription);
			ps2.executeUpdate();// insert to wallet_account
			// getting auto-generated id
			BigInteger txId = BigInteger.valueOf(0L);
			rs = ps2.getGeneratedKeys();
			if (rs.next()) {
				txId = BigInteger.valueOf(rs.getLong(1));
				// System.out.println("Auto Generated txId " + txId);
			}
			txHistory.setTxId(txId);
			txHistory.setAmtCredited(amtCredited);
			txHistory.setAmtDebited(amtDebited);
			txHistory.setTxDateTime(txDateTime);
			txHistory.setTxType(txType);
			txHistory.setTxDescription(txDescription);
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao addTransactionHistory method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao addTransactionHistory method : " + e);
				}
			}
		}
		return txHistory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.IPaymentWalletService#login(com.
	 * capgemini.paymentwallet.model.WalletUser)
	 */
	@Override
	public boolean login(String username, String password) throws PaymentWalletException {
		System.out.println("-----------login------------");
		String sql = "select * from wallet_user where username=? and password=?";
		boolean status = false;
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if (rs.next()) {
				status = true;
			}
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao login method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao login method : " + e);
				}
			}
		}
		return status;
	}

	@Override
	public WalletUser findUserById(BigInteger userId) throws PaymentWalletException {
		System.out.println("-----------findUserById------------");
		WalletUser walletUser = null;
		String sql = "select * from wallet_user where user_id=?";
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, String.valueOf(userId));
			rs = ps.executeQuery();
			if (rs.next()) {
				walletUser = new WalletUser();
				walletUser.setUserId(userId);
				walletUser.setUsername(rs.getString("username"));
				walletUser.setPassword(rs.getString("password"));
				walletUser.setFirstName(rs.getString("first_Name"));
				walletUser.setLastName(rs.getString("last_Name"));
				walletUser.setAddress(rs.getString("address"));
				walletUser.setMobileNo(BigInteger.valueOf(rs.getLong("mobile_No")));
				walletUser.setPin(BigInteger.valueOf(rs.getLong("pin")));
				WalletAccount walletAccount = viewWalletByUserId(userId);
				walletAccount.setWalletUser(walletUser);
				walletUser.setWalletAccount(walletAccount);
			}
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao login method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao login method : " + e);
				}
			}
		}
		return walletUser;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.paymentwallet.services.IPaymentWalletService#addMoney(java.lang
	 * .BigInteger, java.lang.BigInteger, java.lang.BigDecimal)
	 */
	@Override
	public WalletAccount addMoney(BigInteger accId, double amount) throws PaymentWalletException {
		System.out.println("-----------addMoney------------");
		WalletAccount walletAccount = viewWallet(accId);
		if (walletAccount != null) {
			String sql = "update wallet_account set acc_Balance=? where acc_id=?";
			try {
				ps = connection.prepareStatement(sql);
				ps.setBigDecimal(1, BigDecimal.valueOf(amount));
				ps.setString(2, String.valueOf(accId));
				int rec = ps.executeUpdate();
				if (rec < 0) {
					walletAccount = null;
				}
				System.out.println("&&&&&&&&&&&&& -----addMoney-----"+walletAccount);
			} catch (SQLException e) {
				throw new PaymentWalletException("Error: at Dao addMoney method : " + e);
			} finally {
				if (ps != null) {
					try {
						ps.close();
					} catch (SQLException e) {
						throw new PaymentWalletException("Error: at Dao addMoney method : " + e);
					}
				}
			}
		}
		return walletAccount;
	}

	@Override
	public BigDecimal checkBalance(BigInteger accId) throws PaymentWalletException {
		System.out.println("-----------checkBalance------------");
		String sqlSelect = "select acc_balance from wallet_account where acc_id=?";
		BigDecimal accBal = new BigDecimal(0);
		try {
			ps = connection.prepareStatement(sqlSelect);
			ps.setString(1, String.valueOf(accId));
			rs = ps.executeQuery();
			if (rs.next()) {
				accBal = rs.getBigDecimal("acc_balance");
			}
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao checkBalance method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao checkBalance method : " + e);
				}
			}
		}
		return accBal;
	}

	@Override
	public WalletAccount viewWallet(BigInteger accId) throws PaymentWalletException {
		System.out.println("-----------viewWallet------------");
		WalletAccount walletAccount = null;
		String sqlSelect = "select * from wallet_account where acc_id=?";
		System.out.println("viewWallet for accId : " + accId);
		BigInteger userId = BigInteger.valueOf(0);
		try {
			ps = connection.prepareStatement(sqlSelect);
			ps.setString(1, String.valueOf(accId));
			rs = ps.executeQuery();
			if (rs.next()) {
				walletAccount = new WalletAccount();
				walletAccount.setAccId(BigInteger.valueOf(rs.getLong(1)));
				walletAccount.setAccBalance(rs.getBigDecimal("acc_Balance"));
				walletAccount.setAccOpenDateTime(rs.getTimestamp("acc_Open_DateTime").toLocalDateTime());
				userId = BigInteger.valueOf(rs.getLong("user_Id"));

			} else {
				System.out.println("WalletAccount Not Exits !!" + walletAccount);
			}
			if (walletAccount != null) {
				WalletUser walletUser = findUserById(userId);
				walletUser.setWalletAccount(walletAccount);
				walletAccount.setWalletUser(walletUser);
			}
			System.out.println("-----------viewWallet------------"+walletAccount);
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao viewWallet method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao viewWallet method : " + e);
				}
			}
		}
		return walletAccount;
	}

	@Override
	public WalletAccount viewWalletByUserId(BigInteger userId) throws PaymentWalletException {
		System.out.println("-----------viewWalletByUserId------------");
		WalletAccount walletAccount = null;
		String sqlSelect = "select * from wallet_account where user_id=?";
		try {
			ps = connection.prepareStatement(sqlSelect);
			ps.setString(1, String.valueOf(userId));
			rs = ps.executeQuery();
			if (rs.next()) {
				walletAccount = new WalletAccount();
				walletAccount.setAccId(BigInteger.valueOf(rs.getLong(1)));
				walletAccount.setAccBalance(rs.getBigDecimal("acc_Balance"));
				walletAccount.setAccOpenDateTime(rs.getTimestamp("acc_Open_DateTime").toLocalDateTime());
				System.out.println("viewWalletByUserId : walletaccout : " + walletAccount);
			}
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao viewWallet method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao viewWallet method : " + e);
				}
			}
		}
		return walletAccount;
	}

	@Override
	public TransactionHistory fundTransfer(BigInteger fromAccId, BigInteger toAccId, double amount)
			throws PaymentWalletException {
		System.out.println("-----------fundTransfer------------");
		TransactionHistory fromTxHistory = null;
		TransactionHistory toTxHistory = null;
		BigDecimal amt = new BigDecimal(amount);
		BigDecimal accBalFrom = checkBalance(fromAccId);
		BigDecimal accBalTo = checkBalance(toAccId);
		if (accBalFrom.compareTo(BigDecimal.valueOf(amount)) < 1) {// if accBal is >=amount the fund transfer can happen
			try {
				connection.setAutoCommit(false);
				String sql_from = "update wallet_account set acc_balance=? where acc_id=?";
				ps = connection.prepareStatement(sql_from);
				ps.setBigDecimal(1, accBalFrom.subtract(amt));
				ps.setString(2, String.valueOf(fromAccId));
				int recFrom = ps.executeUpdate();
				if (recFrom > 0) {
					String sql_to = "update wallet_account set acc_balance=? where acc_id=?";
					ps1 = connection.prepareStatement(sql_to);
					ps1.setBigDecimal(1, accBalTo.add(amt));
					ps1.setString(2, String.valueOf(toAccId));
					int recTo = ps1.executeUpdate();
					if (recFrom > 0) {
						fromTxHistory = addTransactionHistory(viewWallet(fromAccId), "Fund transfer",
								"Fund transfered to " + toAccId, BigDecimal.ZERO, amt);
						toTxHistory = addTransactionHistory(viewWallet(toAccId), "Fund transfer",
								"Fund recieved from " + fromAccId, amt, BigDecimal.ZERO);
					}
				}
				connection.commit();
			} catch (SQLException e) {
				throw new PaymentWalletException("Error: at Dao fundTransfer method : " + e);
			} finally {
				if (ps != null && ps1 != null) {
					try {
						ps.close();
						ps1.close();
						connection.rollback();
					} catch (SQLException e) {
						throw new PaymentWalletException("Error: at Dao fundTransfer method : " + e);
					}
				}
			}
		} else {
			System.out.println("Insufficient Balance for Fund transfer...." + accBalFrom);
			throw new PaymentWalletException("Insufficient Balance for Fund transfer...." + accBalFrom);
		}

		return fromTxHistory;
	}

	@Override
	public List<TransactionHistory> viewtxHistory(BigInteger accId, LocalDateTime toDate, LocalDateTime fromDate)
			throws PaymentWalletException {
		System.out.println("-----------viewtxHistory------------");
		// SELECT * FROM table WHERE date_column BETWEEN >= '2014-01-10' AND
		// '2015-01-01';
		String sqlSelect = "select * from Transaction_History where acc_id=? and tx_Date_Time between ? and ?";
		TransactionHistory txHis = null;
		WalletAccount walletAccount = viewWallet(accId);
		List<TransactionHistory> txHistories = new ArrayList<>();
		try {
			ps = connection.prepareStatement(sqlSelect);
			ps.setString(1, String.valueOf(accId));
			ps.setDate(2, java.sql.Date.valueOf(java.time.LocalDate.now()));
			ps.setDate(3, java.sql.Date.valueOf(java.time.LocalDate.now()));
			rs = ps.executeQuery();
			while (rs.next()) {
				txHis = new TransactionHistory();
				txHis.setTxId(BigInteger.valueOf(rs.getLong(1)));
				txHis.setWalletAccount(walletAccount);
				txHis.setAmtCredited(rs.getBigDecimal("amt_Credited"));
				txHis.setAmtDebited(rs.getBigDecimal("amt_Debited"));
				txHis.setTxDateTime(rs.getTimestamp("tx_Date_Time").toLocalDateTime());
				txHis.setTxType(rs.getString("tx_type"));
				txHis.setTxDescription(rs.getString("tx_Description"));
				txHistories.add(txHis);
				// System.out.println("Tx : "+txHis);
			}
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao viewWallet method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao viewWallet method : " + e);
				}
			}
		}
		return txHistories;
	}

	@Override
	public List<TransactionHistory> viewAllTxHistory(BigInteger accId) throws PaymentWalletException {
		System.out.println("-----------viewAllTxHistory------------");
		// SELECT * FROM table WHERE date_column BETWEEN >= '2014-01-10' AND
		// '2015-01-01';
		String sqlSelect = "select * from Transaction_History where acc_id=?";
		TransactionHistory txHis = null;
		WalletAccount walletAccount = viewWallet(accId);
		List<TransactionHistory> txHistories = new ArrayList<>();
		try {
			ps = connection.prepareStatement(sqlSelect);
			ps.setString(1, String.valueOf(accId));
			rs = ps.executeQuery();
			while (rs.next()) {
				txHis = new TransactionHistory();
				txHis.setTxId(BigInteger.valueOf(rs.getLong(1)));
				txHis.setWalletAccount(walletAccount);
				txHis.setAmtCredited(rs.getBigDecimal("amt_Credited"));
				txHis.setAmtDebited(rs.getBigDecimal("amt_Debited"));
				txHis.setTxDateTime(rs.getTimestamp("tx_Date_Time").toLocalDateTime());
				txHis.setTxType(rs.getString("tx_type"));
				txHis.setTxDescription(rs.getString("tx_Description"));
				txHistories.add(txHis);
				// System.out.println("Tx : "+txHis);
			}
		} catch (SQLException e) {
			throw new PaymentWalletException("Error: at Dao viewAllTxHistory method : " + e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					throw new PaymentWalletException("Error: at Dao viewAllTxHistory method : " + e);
				}
			}
		}
		return txHistories;
	}
}