/**
 * 
 */
package com.capgemini.paymentwallet.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.paymentwallet.dao.PaymentWalletDao;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.services.PaymentWalletService;

/**
 * @author smitkuma
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class WalletJdbcTest {
	static List<WalletUser> walletUsers;
	
	 @InjectMocks
	 PaymentWalletService  paymentWalletService;
	
	@Mock
	PaymentWalletDao paymentWalletDao;
	
	
	/**
	 * @throws java.lang.Exception
	 */
	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#addMoney(java.lang.Long, java.lang.Integer, java.lang.BigDecimal)}.
	 * @throws PaymentWalletException 
	 */
	@Test
	public void testRegister() throws PaymentWalletException {
		
		//creating user and his WalletAccount by calling both entity setter method as we have 1 to 1 association
		WalletAccount walletAccount1= new WalletAccount();
		WalletUser u1 = new WalletUser("mona", "mona", BigInteger.valueOf(1234), "Mona", "Sen", new BigInteger("9870003333"), "Mumbai");
		/*walletAccount1.setAccBalance(BigDecimal.valueOf(5000.00));
		walletAccount1.setUser(u1);
		u1.setWalletAccount(walletAccount1);*/

		WalletUser registeredUser=paymentWalletService.register(u1,BigDecimal.valueOf(5000.00));
		assertNotNull("User Not Registered!! ", registeredUser);
		System.out.println("Registered User : "+registeredUser);
	}
	@Test
	public void testLogin() throws PaymentWalletException {
		boolean status=paymentWalletService.login("mona", "mona");
		assertEquals(status, true);
		System.out.println("Login status : "+status);
	}
	
	@Disabled
	@Test
	public void testAddMoney() throws PaymentWalletException {
		/*walletUsers=UserDb.getUsers();
			walletUsers.forEach(System.out::println);
		    WalletAccount walletAccount1= new WalletAccount();
			WalletUser u1 = walletUsers.get(0);
			System.out.println(" user account u1 :"+u1);
			walletAccount1=paymentWalletService.addMoney(BigInteger.valueOf(1002), BigInteger.valueOf(1234), 1000.00);
			assertNotNull("Account Does Not exists", walletAccount1);
			BigDecimal actual= walletAccount1.getAccBalance();
			BigDecimal expected=BigDecimal.valueOf(2000.0);
			assertEquals(actual,expected);
			System.out.println(" walletAccount updated balance "+expected);*/
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#checkBalance(java.lang.Long, java.lang.Integer)}.
	 * @throws PaymentWalletException 
	 */
	@Disabled
	@Test 
	public void testCheckBalance() throws PaymentWalletException {
		/*BigDecimal expected=new BigDecimal("2000.0");
		BigDecimal accBalance=paymentWalletService.checkBalance(BigInteger.valueOf(1002), BigInteger.valueOf(1234));
		assertEquals(expected,accBalance);
		System.out.println(" walletAccount Balance of acc 1002 is "+accBalance);
		*/
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#viewWallet(java.lang.Long, java.lang.Integer)}.
	 * @throws PaymentWalletException 
	 */
	@Disabled
	@Test 
	public void testViewWallet() throws PaymentWalletException {
		
		/*WalletAccount walletAccount=paymentWalletService.viewWallet(BigInteger.valueOf(1002), BigInteger.valueOf(1234));
		assertNotNull("walletAccount Does Not exists", walletAccount);
		System.out.println(" walletAccount "+walletAccount);	*/	
	}

	/**
	 * Test method for {@link com.capgemini.paymentwallet.dao.PaymentWalletDao#fundTransfer(java.lang.Integer, java.lang.Long, java.lang.Long, java.lang.BigDecimal)}.
	 * @throws PaymentWalletException 
	 */
	@Disabled
	@Test 
	public void testFundTransfer() throws PaymentWalletException {
		/*TransactionHistory transactionHistory=paymentWalletService.fundTransfer(BigInteger.valueOf(1234), BigInteger.valueOf(1001), BigInteger.valueOf(1002), 200.00);
		assertNotNull("Transaction not happened", transactionHistory);
		System.out.println(" transactionHistory "+transactionHistory);*/
	}

}
