/**
 * 
 */
package com.capgemini.paymentwallet.client;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.paymentwallet.dao.IPaymentWalletDao;
import com.capgemini.paymentwallet.dao.PaymentWalletDao;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;

/**
 * @author smitkuma
 *
 */
public class PaymentWalletClient {
private static IPaymentWalletDao paymentWalletDao= new PaymentWalletDao();
	public static void main(String[] args) throws PaymentWalletException {
		
		//creating user and his WalletAccount by calling both entity setter method as we have 1 to 1 association
		WalletAccount walletAccount1= new WalletAccount();
		WalletUser u1 = new WalletUser("mona", "mona", BigInteger.valueOf(1234), "Mona", "Sen", new BigInteger("9870003333"), "Mumbai");
		walletAccount1.setAccBalance(BigDecimal.valueOf(15000.00));
		walletAccount1.setWalletUser(u1);
		u1.setWalletAccount(walletAccount1);

		WalletUser registeredUser1=paymentWalletDao.register(u1,BigDecimal.valueOf(5000.00));
		System.out.println("Registered User 1: "+registeredUser1);
		
		WalletAccount walletAccount2= new WalletAccount();
		WalletUser u2 = new WalletUser("raj", "raj", BigInteger.valueOf(1234), "Raj", "Mathur", new BigInteger("9870001144"), "Pune");
		walletAccount2.setAccBalance(BigDecimal.valueOf(10000.00));
		walletAccount2.setWalletUser(u2);
		u2.setWalletAccount(walletAccount2);

		WalletUser registeredUser2=paymentWalletDao.register(u2,BigDecimal.valueOf(15000.00));
		System.out.println("Registered User 2: "+registeredUser2);
		
		//login
	/*	boolean status=paymentWalletDao.login("mona", "mona");
		if(status) System.out.println("hello ,"+u1.getFirstName()+ " Login Successfull status : "+status);
		else
			System.err.println("Invalid Credentials ");*/
		
		//find user by userId
		BigInteger fromUserId=registeredUser1.getUserId();
		WalletUser fromFoundUser=paymentWalletDao.findUserById(fromUserId);
		System.out.println("fromFoundUser : "+fromFoundUser);
		
		BigInteger toUserId=registeredUser2.getUserId();
		WalletUser toFoundUser=paymentWalletDao.findUserById(toUserId);
		System.out.println("toFoundUser : "+toFoundUser);
		
		//add money to walletAccount 1
		BigInteger fromAccId= fromFoundUser.getWalletAccount().getAccId();
		WalletAccount updatedWalletAcc =paymentWalletDao.addMoney(BigInteger.valueOf(1022), 2000.00);
		System.out.println("**** After AddMony updatedWalletAcc : "+updatedWalletAcc);
		
		//fund Transfer from acc  to To acc
		BigInteger toAccId= toFoundUser.getWalletAccount().getAccId();
		paymentWalletDao.fundTransfer(fromAccId, toAccId, 200);
		
	
		//view transaction history for an account from and to specific date
		List<TransactionHistory> txHistories= paymentWalletDao.viewtxHistory(fromAccId, LocalDateTime.of(2019, 9, 10,0,0,0), LocalDateTime.of(2019, 9, 11,0,0,0));
		System.out.println("Tx Histories for accId : "+fromAccId);
		
		txHistories.forEach(System.out::println);
		
	}

}
