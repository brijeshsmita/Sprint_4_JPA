/**
 * 
 */
package com.capgemini.paymentwallet.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public interface IPaymentWalletService {
	public WalletUser register (WalletUser walletUser,BigDecimal accBalance) throws PaymentWalletException;
	public WalletUser findUserById (BigInteger userId) throws PaymentWalletException;
	public boolean login (String username, String password)throws PaymentWalletException;
	public WalletAccount addMoney (BigInteger accId, double amount)throws PaymentWalletException;
	public BigDecimal checkBalance (BigInteger accId)throws PaymentWalletException; 
	public WalletAccount viewWallet (BigInteger accId)throws PaymentWalletException; 
	public TransactionHistory fundTransfer (BigInteger fromAccId, BigInteger toAccId, double amount)throws PaymentWalletException; 
	public List<TransactionHistory> viewtxHistory (BigInteger accId, LocalDateTime toDate,  LocalDateTime fromDate)throws PaymentWalletException; 
}
