/**
 * 
 */
package com.cg.ewallet.rest.exception;

/**
 * @author smitkuma
 *
 */
public class TxHistoryException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6304469802731292634L;

	/**
	 * 
	 */
	public TxHistoryException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public TxHistoryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
