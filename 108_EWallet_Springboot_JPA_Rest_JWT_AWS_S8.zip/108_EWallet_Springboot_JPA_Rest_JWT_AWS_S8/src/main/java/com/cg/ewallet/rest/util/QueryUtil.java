/**
 
 */
package com.cg.ewallet.rest.util;

/**
 @author smitkuma
 *
 */
public class QueryUtil {
	private QueryUtil(){}
	public static final String VIEW_TX_BY_DATE = "select acc from TransactionHistory acc where acc.walletAccount= :walletAccount and tx_Date_Time between :toDate and :fromDate";
	public static final String VIEW_TX_HIS = "select acc from TransactionHistory acc where acc.walletAccount= :walletAccount";
	public static final String VIEW_ALL_TX_HIS = "from TransactionHistory where accId=:accId";
	public static final String UPDATE_ACC_QUERY = "update WalletAccount set accBalance=:accBalance where accId=:accId";
	public static final String CHECK_BALANCE ="select w.accBalance from WalletAccount w where w.accId=:accId";
	public static final String VIEW_WALLET = "from WalletAccount where accId=:accId";
	public static final String FIND_USER_BY_ID = "from WalletUser w where w.userId=:userId";
	public static final String VIEW_WALLET_BY_USERID = "Select DISTINCT u FROM WalletUser u INNER JOIN FETCH u.walletAccount acc where u.userId=:userId";
	public static final String CHECK_LOGIN = "from WalletUser where username=:uname and userpass=:upass";
	
}
