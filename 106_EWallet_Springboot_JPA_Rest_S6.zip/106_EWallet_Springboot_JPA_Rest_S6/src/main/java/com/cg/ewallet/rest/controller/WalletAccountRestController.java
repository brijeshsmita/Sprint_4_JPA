/**
 * 
 */
package com.cg.ewallet.rest.controller;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ewallet.rest.model.WalletAccount;
import com.cg.ewallet.rest.services.WalletAccountService;

/**
 * author: smitkuma Description : Rest controller for WalletUser created Date:
 * 18/10/2019 Controller with different HTTP methods as GET,POST,DELETE and
 * their respective URL mappings class level request mapping as "walletAccounts"
 * return type is JSON
 */
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/wallet-account")
public class WalletAccountRestController {

	@Autowired
	private WalletAccountService walletAccountService;

	public WalletAccountService getWalletAccountService() {
		return walletAccountService;
	}

	/*
	 * Mapping for the walletAccount home page
	 */
//  http://localhost:8082/ewallet-api/wallet-account/
	@GetMapping(value = "/")
	public String displayHomePage(Model model) {
		logger.info("");
		return "walletAccount";
	}

	// http://localhost:8082/ewallet-api/wallet-account/add-money/1001/200
	@RequestMapping(value = "/add-money/{accId}/{amount}", headers = "Accept=application/json")
	public ResponseEntity<WalletAccount> addMoney(@PathVariable Long accId, @PathVariable double amount) {
		WalletAccount walletAccount = walletAccountService.addMoney(accId, amount);
		if (walletAccount == null) {
			return new ResponseEntity<WalletAccount>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<WalletAccount>(walletAccount, HttpStatus.OK);
		}
	}

	// http://localhost:8082/ewallet-api/wallet-account/fund-transfer/1001/1002/50
	@RequestMapping(value = "/fund-transfer/{fromAccId}/{toAccId}/{amount}", headers = "Accept=application/json")
	public ResponseEntity<WalletAccount> fundTransfer(@PathVariable Long fromAccId, @PathVariable Long toAccId,
			@PathVariable double amount) {
		WalletAccount walletAccount = walletAccountService.fundTransfer(fromAccId, toAccId, amount);
		if (walletAccount == null) {
			return new ResponseEntity<WalletAccount>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<WalletAccount>(walletAccount, HttpStatus.OK);
		}
	}

// http://localhost:8082/ewallet-api/wallet-account/check-balance/1001
	@GetMapping(value = "/check-balance/{accId}", headers = "Accept=application/json")
	public ResponseEntity<BigDecimal> checkBalanceById(@PathVariable Long accId) {
		BigDecimal balance = walletAccountService.checkBalance(accId);
		if (balance == null) {
			return new ResponseEntity<BigDecimal>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<BigDecimal>(balance, HttpStatus.OK);
		}
	}

	// http://localhost:8082/ewallet-api/wallet-account/view-wallet/1001
	@GetMapping(value = "/view/{accId}", headers = "Accept=application/json")
	public ResponseEntity<WalletAccount> getWalletAccount(@PathVariable Long accId) {
		WalletAccount walletAccount = walletAccountService.viewWallet(accId);
		if (walletAccount == null) {
			return new ResponseEntity<WalletAccount>(HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<WalletAccount>(walletAccount, HttpStatus.OK);
		}
	}

	// Getters And Setters
	public void setWalletAccountService(WalletAccountService walletAccountService) {
		this.walletAccountService = walletAccountService;
	}

	private static final Logger logger;
	static {
		logger = LoggerFactory.getLogger(WalletAccountRestController.class);
	}

	public static Logger getLogger() {
		return logger;
	}
}
