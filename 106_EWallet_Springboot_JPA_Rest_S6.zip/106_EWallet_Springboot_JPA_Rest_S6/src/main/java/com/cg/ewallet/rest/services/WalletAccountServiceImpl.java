
package com.cg.ewallet.rest.services;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ewallet.rest.dao.WalletAccountDao;
import com.cg.ewallet.rest.exception.PaymentWalletException;
import com.cg.ewallet.rest.model.TransactionHistory;
import com.cg.ewallet.rest.model.WalletAccount;
import com.cg.ewallet.rest.repository.TxHistoryRepository;
import com.cg.ewallet.rest.repository.WalletAccountRepository;

/**
 * @author smitkuma
 *
 */
@Service(value = "walletAccountService")
public class WalletAccountServiceImpl implements WalletAccountService {
	// prep work create instance of dao layer
	@Autowired
	private  WalletAccountDao walletAccountDao;
	@Autowired
	private TxHistoryRepository txHistoryRepository;
	@Autowired
	private  WalletAccountRepository walletAccountRepository;
	private static Logger myLogger;
	/*
	 * static block to declare logger and create the instance of DaoImpl
	 */

	static {
		setMyLogger(LoggerFactory.getLogger(WalletAccountServiceImpl.class));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.rest.ewallet.rest.services.WalletAccountService#addMoney(java.lang.
	 * Long, java.lang.Long, java.lang.BigDecimal)
	 * 
	 * @param accId
	 * 
	 * @param amount
	 * 
	 * @return WalletAccount.
	 * 
	 * @throws PaymentWalletException
	 */
	@Transactional
	@Override
	public WalletAccount addMoney(Long accId, double amount) throws PaymentWalletException {

		WalletAccount walletAccount = walletAccountRepository.findByAccId(accId);
		if(walletAccount!=null) {
			double updatedAmt=walletAccount.getAccBalance().doubleValue()+amount;
			walletAccount.setAccBalance(BigDecimal.valueOf(updatedAmt));		
		}
		TransactionHistory transactionHistory= new TransactionHistory(walletAccount, LocalDateTime.now(),
				"Add Money", BigDecimal.valueOf(amount), BigDecimal.valueOf(0.0), "Money Added in the Wallet");
		txHistoryRepository.save(transactionHistory);
		return walletAccount;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.rest.ewallet.rest.services.WalletAccountService#checkBalance(java.
	 * lang.Long, java.lang.Long) This is the checkBalance method which
	 * returns balance form the specific WalletAccount
	 * 
	 * @param accId
	 * 
	 * @return BigDecimal.
	 * 
	 * @throws PaymentWalletException
	 */
	@Transactional
	@Override
	public BigDecimal checkBalance(Long accId) throws PaymentWalletException {
		WalletAccount walletAccount = walletAccountRepository.findByAccId(accId);
		return (walletAccount!=null)? walletAccount.getAccBalance():null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.rest.ewallet.rest.services.WalletAccountService#viewWallet(java.
	 * lang.Long, java.lang.Long) This is the viewWallet method which
	 * returns WalletAccount for the specific accId
	 * 
	 * @param accId
	 * 
	 * @return WalletAccount.
	 * 
	 * @throws PaymentWalletException
	 */
	@Transactional
	@Override
	public WalletAccount viewWallet(Long accId) throws PaymentWalletException {

		WalletAccount walletAccount = walletAccountRepository.findByAccId(accId);
		return walletAccount;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.rest.ewallet.rest.services.WalletAccountService#fundTransfer(java.
	 * lang.Long, java.lang.Long, java.lang.Long) This is the
	 * fundTransfer method which transfer amt from 1 WalletAccount to another
	 * 
	 * @param fromAccId
	 * 
	 * @param toAccId
	 * 
	 * @param amount
	 * 
	 * @return WalletAccount.
	 * 
	 * @throws PaymentWalletException
	 */
	@Transactional
	@Override
	public WalletAccount fundTransfer(Long fromAccId, Long toAccId, double amount)
			throws PaymentWalletException {
		WalletAccount walletAccount= walletAccountDao.fundTransfer(fromAccId, toAccId, amount);
		TransactionHistory transactionHistory= new TransactionHistory(walletAccount, LocalDateTime.now(),
				"Fund Transfer", BigDecimal.valueOf(0), BigDecimal.valueOf(amount), "Transfered Money to "+toAccId);
		txHistoryRepository.save(transactionHistory);
		WalletAccount toAcc= walletAccountRepository.findByAccId(toAccId);
		transactionHistory= new TransactionHistory(toAcc, LocalDateTime.now(),
				"Fund Recieved", BigDecimal.valueOf(amount), BigDecimal.valueOf(0.0), 
				"Money added from "+fromAccId);
		txHistoryRepository.save(transactionHistory);
	
		return walletAccount;
	}

	public  WalletAccountDao getPaymentWalletDao() {
		return walletAccountDao;
	}

	public  void setPaymentWalletDao(WalletAccountDao walletAccountDao) {
		this.walletAccountDao = walletAccountDao;
	}

	/**
	 * @return the walletAccountDao
	 */
	public  WalletAccountDao getWalletAccountDao() {
		return walletAccountDao;
	}

	/**
	 * @param walletAccountDao the walletAccountDao to set
	 */
	public  void setWalletAccountDao(WalletAccountDao walletAccountDao) {
		this.walletAccountDao = walletAccountDao;
	}

	/**
	 * @return the walletAccountRepository
	 */
	public  WalletAccountRepository getWalletAccountRepository() {
		return walletAccountRepository;
	}

	/**
	 * @param walletAccountRepository the walletAccountRepository to set
	 */
	public  void setWalletAccountRepository(WalletAccountRepository walletAccountRepository) {
		this.walletAccountRepository = walletAccountRepository;
	}

	/**
	 * @return the myLogger
	 */
	public static Logger getMyLogger() {
		return myLogger;
	}

	/**
	 * @param myLogger the myLogger to set
	 */
	public static void setMyLogger(Logger myLogger) {
		WalletAccountServiceImpl.myLogger = myLogger;
	}

}
