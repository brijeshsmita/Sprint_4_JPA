/**
 * 
 */
package com.cg.ewallet.rest.services;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ewallet.rest.dao.TxHistoryDao;
import com.cg.ewallet.rest.exception.TxHistoryException;
import com.cg.ewallet.rest.model.TransactionHistory;
import com.cg.ewallet.rest.model.WalletAccount;
import com.cg.ewallet.rest.repository.TxHistoryRepository;

/**
 * @author smitkuma
 *
 */
@Service(value = "txHistoryService")
public class TxHistoryServiceImpl implements TxHistoryService {
	// prep work create instance of dao layer
	@Autowired
	private TxHistoryDao txHistoryDao;
	@Autowired
	private TxHistoryRepository txHistoryRepository;
	private static Logger myLogger;
	/*
	 * static block to declare logger and create the instance of DaoImpl
	 */
	static {
		setMyLogger(LoggerFactory.getLogger(TxHistoryServiceImpl.class));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.rest.ewallet.rest.services.TxHistoryService#viewtxHistory(java.
	 * time.LocalDateTime, java.time.LocalDateTime)
	 */
	@Transactional
	@Override
	public List<TransactionHistory> viewtxHistory(Long accId, LocalDateTime toDate, LocalDateTime fromDate)
			throws TxHistoryException {

		List<TransactionHistory> transactionHistories = txHistoryDao.viewtxHistory(accId, toDate, fromDate);
		if(transactionHistories!=null) myLogger.info(" TX history found : "+transactionHistories); 
		else myLogger.error(" TX history NOT found : "+transactionHistories);
		return transactionHistories;
	}

	/*
	 * This is the viewAllTxHistory method which provide the list of all the tx of
	 * the specific account
	 * 
	 * @param accId
	 * 
	 * @return List<TransactionHistory>.
	 * 
	 * @throws TxHistoryException
	 */
	@Transactional
	@Override
	public List<TransactionHistory> viewAllTxHistory(Long accId) throws TxHistoryException {

		List<TransactionHistory> transactionHistories = txHistoryDao.viewAllTxHistory(accId);

		return transactionHistories;
	}

	/*
	 * This is the viewAllTxHistory method which provide the list of all the tx of
	 * the specific account
	 * 
	 * @param accId
	 * 
	 * @return List<TransactionHistory>.
	 * 
	 * @throws TxHistoryException
	 */
	@Transactional
	@Override
	public List<TransactionHistory> addTransactionHistory(WalletAccount walletAccount, String txType,
			String txDescription, double amtCredited, double amtDebited) throws TxHistoryException {
		TransactionHistory transactionHistory= new TransactionHistory(walletAccount, LocalDateTime.now(), txType, BigDecimal.valueOf(amtCredited), BigDecimal.valueOf(amtDebited), txDescription);
		txHistoryRepository.save(transactionHistory);
		List<TransactionHistory> transactionHistories = txHistoryRepository.findAll();
		return transactionHistories;
	}

	public TxHistoryDao getPaymentWalletDao() {
		return txHistoryDao;
	}

	public void setPaymentWalletDao(TxHistoryDao txHistoryDao) {
		this.txHistoryDao = txHistoryDao;
	}

	/**
	 * @return the myLogger
	 */
	public static Logger getMyLogger() {
		return myLogger;
	}

	/**
	 * @param myLogger the myLogger to set
	 */
	public static void setMyLogger(Logger myLogger) {
		TxHistoryServiceImpl.myLogger = myLogger;
	}
}
