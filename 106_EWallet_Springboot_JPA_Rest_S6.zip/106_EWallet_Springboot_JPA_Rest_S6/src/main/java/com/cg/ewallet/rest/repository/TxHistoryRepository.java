/**
 * 
 */
package com.cg.ewallet.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ewallet.rest.model.TransactionHistory;
import com.cg.ewallet.rest.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public interface TxHistoryRepository extends JpaRepository<TransactionHistory, Long> {
	public WalletAccount findByTxId(Long txId);
}
