package com.cg.ewallet.rest.model;


public enum WalletAccStatus {

    APPROVED,REJECTED,PENDING,CLOSED;

}
