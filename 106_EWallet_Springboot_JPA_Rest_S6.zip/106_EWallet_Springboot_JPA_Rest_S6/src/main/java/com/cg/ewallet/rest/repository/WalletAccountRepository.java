/**
 * 
 */
package com.cg.ewallet.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ewallet.rest.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public interface WalletAccountRepository extends JpaRepository<WalletAccount, Long> {
	public WalletAccount findByAccId(Long accId);
}
