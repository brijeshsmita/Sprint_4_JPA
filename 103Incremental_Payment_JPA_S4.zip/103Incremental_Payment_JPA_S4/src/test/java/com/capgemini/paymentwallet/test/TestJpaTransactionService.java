/**
 * 
 */
package com.capgemini.paymentwallet.test;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.paymentwallet.dao.JpaTransactionDaoImpl;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.exception.JpaTransactionException;
import com.capgemini.paymentwallet.services.JpaTransactionServiceImpl;
import com.capgemini.paymentwallet.util.ErrorMessageUtil;
import com.capgemini.paymentwallet.util.JPAUtil;
import com.capgemini.paymentwallet.util.MyLoggerUtil;

/**
 * @author smitkuma
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TestJpaTransactionService {
	private static Logger myLogger;
	static {
		try {
			MyLoggerUtil.configure();
			myLogger = Logger.getLogger("TestJpaTransactionService.class");
		} catch (Exception e) {
			myLogger.error(ErrorMessageUtil.LOGGER_ERROR_MSG + e);
		}
	}
	@InjectMocks
	JpaTransactionServiceImpl jpaTransactionService;

	@Mock
	JpaTransactionDaoImpl jpaTransactionDao;
	
	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.JpaTransactionServiceImpl#beginTx()}.
	 * 
	 * @throws JpaTransactionException
	 */

	@Test
	public void testBeginTx() throws JpaTransactionException {
		myLogger.info("**** testBeginTx***************");
		EntityTransaction transaction = jpaTransactionService.beginTx();
		myLogger.info("**** After testBeginTx : " + transaction);
		assertNotNull("EntityTransaction not begin !! ", transaction);
	}
	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.JpaTransactionServiceImpl#testCloseTx()}.
	 * 
	 * @throws JpaTransactionException
	 */

	@Test
	public void testCloseTx() throws JpaTransactionException {
		myLogger.info("**** testCloseTx***************");
		EntityTransaction transaction = jpaTransactionService.beginTx();
		myLogger.info("**** After testCloseTx : " + transaction);
		assertNotNull("EntityTransaction not Committed !! ", transaction);
	}

	
	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.JpaTransactionServiceImpl#beginTx()}.
	 * 
	 * @throws JpaTransactionException
	 */

	@Test
	public void testRollbackTx() throws JpaTransactionException {
		myLogger.info("**** testRollbackTx***************");
		EntityTransaction transaction = jpaTransactionService.beginTx();
		myLogger.info("**** After testRollbackTx : " + transaction);
		assertNotNull("EntityTransaction not rolledback !! ", transaction);
	}

}
