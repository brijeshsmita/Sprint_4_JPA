/**
 * 
 */
package com.capgemini.paymentwallet.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Properties;

import javax.persistence.EntityManagerFactory;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.paymentwallet.dao.WalletAccountDaoImpl;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.services.WalletAccountServiceImpl;
import com.capgemini.paymentwallet.util.ErrorMessageUtil;
import com.capgemini.paymentwallet.util.JPAUtil;

/**
 * @author smitkuma
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TestWalletAccountService {
	private static Logger myLogger;
	static {
		try {
			Properties props = System.getProperties();
			String userDir = props.getProperty("user.dir") + "/src/main/resources/";
			PropertyConfigurator.configure(userDir + "log4j.properties");
			myLogger = Logger.getLogger("TestWalletAccountService.class");
		} catch (Exception e) {
			myLogger.error(ErrorMessageUtil.LOGGER_ERROR_MSG + e);
		}
	}
	@InjectMocks
	WalletAccountServiceImpl paymentWalletService;

	@Mock
	WalletAccountDaoImpl paymentWalletDao;

	
	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.WalletAccountServiceImpl#addMoney(java.math.BigInteger, double)}.
	 * 
	 * @throws PaymentWalletException
	 */

	@Test
	public void testAddMoney() throws PaymentWalletException {
		myLogger.info("**** testAddMoney***************");
		WalletAccount updatedWalletAcc = paymentWalletService.addMoney(BigInteger.valueOf(1001), 2000.00);
		myLogger.info("**** After AddMony updatedWalletAcc : " + updatedWalletAcc);

		assertNotNull("Money Not Added to WalletAccount !! " + 1009, updatedWalletAcc);
	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.WalletAccountServiceImpl#checkBalance(java.math.BigInteger)}.
	 * 
	 * @throws PaymentWalletException
	 */

	@Test
	public void testCheckBalance() throws PaymentWalletException {
		myLogger.info("**** testCheckBalance***************");
		BigDecimal balance = paymentWalletService.checkBalance(BigInteger.valueOf(1001));
		myLogger.info("**** After testCheckBalance : " + balance);
		assertNotNull("WalletAccount not exits !! " + 1001, balance);
	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.WalletAccountServiceImpl#viewWallet(java.math.BigInteger)}.
	 * 
	 * @throws PaymentWalletException
	 */

	@Test
	public void testViewWallet() throws PaymentWalletException {
		myLogger.info("**** testViewWallet***************");
		WalletAccount walletAccount = paymentWalletService.viewWallet(BigInteger.valueOf(1001));
		myLogger.info("**** After testViewWallet : " + walletAccount);
		assertNotNull(" WalletAccount does not Exits !! " + 1001, walletAccount);
	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.WalletAccountServiceImpl#fundTransfer(java.math.BigInteger, java.math.BigInteger, double)}.
	 * 
	 * @throws PaymentWalletException
	 */

	@Test
	public void testFundTransfer() throws PaymentWalletException {
		myLogger.info("**** testFundTransfer***************");
		// fund Transfer from acc to To acc
		BigInteger toAccId = BigInteger.valueOf(1000);
		BigInteger fromAccId = BigInteger.valueOf(1001);
		WalletAccount walletAccount = paymentWalletService.fundTransfer(fromAccId, toAccId, 4000.00);
		myLogger.info("**** After testFundTransfer : " + walletAccount);
		assertNotNull(" FundTransfer Failed !!  from 1000 to 1001", walletAccount);

	}	
}
