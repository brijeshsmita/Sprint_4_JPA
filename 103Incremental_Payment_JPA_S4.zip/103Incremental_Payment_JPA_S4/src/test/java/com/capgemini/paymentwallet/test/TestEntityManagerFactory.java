/**
 * 
 */
package com.capgemini.paymentwallet.test;

import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.paymentwallet.dao.JpaTransactionDaoImpl;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.exception.TxHistoryException;
import com.capgemini.paymentwallet.services.JpaTransactionServiceImpl;
import com.capgemini.paymentwallet.util.ErrorMessageUtil;
import com.capgemini.paymentwallet.util.JPAUtil;
import com.capgemini.paymentwallet.util.MyLoggerUtil;

/**
 * @author smitkuma
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TestEntityManagerFactory {
	private static Logger myLogger;
	static {
		try {
			MyLoggerUtil.configure();
			myLogger = Logger.getLogger("TestEntityManagerFactory.class");
		} catch (Exception e) {
			myLogger.error(ErrorMessageUtil.LOGGER_ERROR_MSG + e);
		}
	}

	/**
	 * Test method for 
	 * {@link com.capgemini.paymentwallet.util.JPAUtil#getEntityManagerFactory()}.
	 * 
	 * @throws PaymentWalletException
	 */

	@Test
	public void testEntityManagerFactory() throws PaymentWalletException {
		EntityManagerFactory emf = JPAUtil.getEntityManagerFactory();
		assertNotNull(emf);
		myLogger.info(" EntityManagerFactoryTest :" + emf);
	}
	
}
