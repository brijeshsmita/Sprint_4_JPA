/**
 * 
 */
package com.capgemini.paymentwallet.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Properties;

import javax.persistence.EntityManagerFactory;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.paymentwallet.dao.TxHistoryDao;
import com.capgemini.paymentwallet.exception.TxHistoryException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.services.TxHistoryServiceImpl;
import com.capgemini.paymentwallet.util.ErrorMessageUtil;
import com.capgemini.paymentwallet.util.JPAUtil;

/**
 * @author smitkuma
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TestTxHistoryService {
	private static Logger myLogger;
	static {
		try {
			Properties props = System.getProperties();
			String userDir = props.getProperty("user.dir") + "/src/main/resources/";
			PropertyConfigurator.configure(userDir + "log4j.properties");
			myLogger = Logger.getLogger("TestWalletAccountService.class");
		} catch (Exception e) {
			myLogger.error(ErrorMessageUtil.LOGGER_ERROR_MSG + e);
		}
	}
	@InjectMocks
	TxHistoryServiceImpl TxHistoryService;

	@Mock
	TxHistoryDao paymentWalletDao;


	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.TxHistoryServiceImpl#viewtxHistory(java.math.BigInteger, java.time.LocalDateTime, java.time.LocalDateTime)}.
	 * @throws TxHistoryException 
	 */

	@Test
	public void testViewtxHistory() throws TxHistoryException {
		myLogger.info("**** testViewtxHistory* by dates**************");
		// fund Transfer from acc to To acc
		List<TransactionHistory> txHistories = TxHistoryService.viewtxHistory(BigInteger.valueOf(1000), LocalDateTime.of(2019, 9, 10, 0, 0, 0), LocalDateTime.of(2019, 9, 11, 0, 0, 0));
		myLogger.info("**** After testViewtxHistory by dates: " + txHistories);
		assertNotNull("ViewtxHistories Failed by dates !!  for acc 1000 ", txHistories);

	}
	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.TxHistoryServiceImpl#viewAllTxHistory(java.math.BigInteger)}.
	 * @throws TxHistoryException 
	 */

	@Test
	public void testViewAllTxHistory() throws TxHistoryException {
		myLogger.info("**** testViewAllTxHistory***************");
		List<TransactionHistory> txHistories = TxHistoryService.viewAllTxHistory(BigInteger.valueOf(1000));
		myLogger.info("**** After testViewAllTxHistory : " + txHistories);
		assertNotNull("ViewAlltxHistories Failed !!  for acc 1000 ", txHistories);

	}
	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.TxHistoryServiceImpl#addTransactionHistory(java.math.BigInteger, java.time.LocalDateTime, java.time.LocalDateTime)}.
	 * @throws TxHistoryException 
	 */

	@Test
	public void testAddTransactionHistory() throws TxHistoryException {
		myLogger.info("**** testAddTransactionHistory***************");
		// Wallet User
		WalletUser walletUser = new WalletUser("ram", "ram", BigInteger.valueOf(1112), "Ram", "Singh",
		BigInteger.valueOf(9870004443L), "Pune");
		// Wallet Account
		WalletAccount walletAccount = new WalletAccount();
		walletAccount.setAccBalance(BigDecimal.valueOf(15000.00));
		walletAccount.setWalletUser(walletUser);
		walletAccount.setAccOpenDateTime(LocalDateTime.now());
		// Transaction History
		List<TransactionHistory> txHistories = TxHistoryService.addTransactionHistory(walletAccount, "Account Open","Opening the new Wallet Account",10000.00, 0.0);
		myLogger.info("**** After testAddTransactionHistory : " + txHistories);
		assertNotNull("testAddTransactionHistory Failed !!  for acc 1000 ", txHistories);

	}


}
