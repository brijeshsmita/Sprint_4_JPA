/**
 * 
 */
package com.capgemini.paymentwallet.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.EntityManagerFactory;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.paymentwallet.dao.WalletUserDaoImpl;
import com.capgemini.paymentwallet.exception.WalletUserException;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.services.WalletUserServiceImpl;
import com.capgemini.paymentwallet.util.ErrorMessageUtil;
import com.capgemini.paymentwallet.util.JPAUtil;
import com.capgemini.paymentwallet.util.MyLoggerUtil;

/**
 * @author smitkuma
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class TestWalletUserService {
	private static Logger myLogger;
	static {
		try {
			MyLoggerUtil.configure();
			myLogger = Logger.getLogger("TestWalletUserService.class");
		} catch (Exception e) {
			myLogger.error(ErrorMessageUtil.LOGGER_ERROR_MSG + e);
		}
	}
	@InjectMocks
	WalletUserServiceImpl walletUserService;

	@Mock
	WalletUserDaoImpl paymentWalletDao;
	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.WalletUserServiceImpl#register(com.capgemini.paymentwallet.model.WalletUser, java.math.BigDecimal)}.
	 * 
	 * @throws WalletUserException
	 */

	@Test
	public void testEntityManagerFactory() throws WalletUserException {
		EntityManagerFactory emf = JPAUtil.getEntityManagerFactory();
		assertNotNull(emf);
		myLogger.info(" EntityManagerFactoryTest :" + emf);
	}

	@Test
	public void testRegister() throws WalletUserException {
		WalletAccount walletAccount = new WalletAccount();
		WalletUser walletUser = new WalletUser("mona", "mona", BigInteger.valueOf(1003), "Mona", "Sen",
				new BigInteger("9870003333"), "Mumbai");
		walletUser.setWalletAccount(walletAccount);
		WalletUser registeredUser = walletUserService.register(walletUser, BigDecimal.valueOf(5000.00));
		assertNotNull("User Not Registered!! ", registeredUser);
		myLogger.info("Registered User : " + registeredUser);
	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.WalletUserServiceImpl#login(java.lang.String, java.lang.String)}.
	 * 
	 * @throws WalletUserException
	 */

	@Test
	public void testLogin() throws WalletUserException {
		boolean status = walletUserService.login("mona", "mona");
		assertTrue(status);
		myLogger.info("Login status : " + status);

	}

	/**
	 * Test method for
	 * {@link com.capgemini.paymentwallet.services.WalletUserServiceImpl#findUserById(java.math.BigInteger)}.
	 */
	@Test
	public void testFindUserById() {
		WalletUser fromFoundUser = walletUserService.findUserById(BigInteger.valueOf(1));
		myLogger.info("fromFoundUser : " + fromFoundUser);
		assertNotNull("User Not Found!! ", fromFoundUser);
	}

}
