/**
 * 
 * @throws WalletUserException */
package com.capgemini.paymentwallet.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.capgemini.paymentwallet.exception.WalletUserException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.util.ErrorMessageUtil;
import com.capgemini.paymentwallet.util.JPAUtil;
import com.capgemini.paymentwallet.util.MyLoggerUtil;
import com.capgemini.paymentwallet.util.QueryUtil;

/**
 * @author smitkuma
 *
 * @throws WalletUserException */
public class WalletUserDaoImpl implements WalletUserDao {
	private static EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
	private static Logger myLogger;
	/*
	 * static block to configure logger and obtain entity manager factory object
	 */
	static {

		MyLoggerUtil.configure();
		myLogger = Logger.getLogger(WalletUserDaoImpl.class);
		entityManagerFactory = JPAUtil.getEntityManagerFactory();
		myLogger.info("entityManagerFactory Obtained!!");

	}
/*
 * constructor to obtain entityManager object
 */
	public WalletUserDaoImpl() {

		entityManager = entityManagerFactory.createEntityManager();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.WalletAccountService#register(com.
	 * capgemini.paymentwallet.model.WalletUser) 
	 * This is the register method which create a new user and wallet account	  
	 * @param walletUser 
	 * @param accBalance.	 
	 * @return WalletUser.
	 * @throws WalletUserException */
	@Override
	public WalletUser register(WalletUser walletUser, BigDecimal accBalance) throws WalletUserException {
		myLogger.info("-----------register------------");
		entityManager.persist(walletUser);
		return walletUser;

	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.WalletAccountService#login(com.
	 * capgemini.paymentwallet.model.WalletUser)
	 * This is the login method which authenticate user
	 * @param username 
	 * @param userpass.	 
	 * @return boolean.
	 * @throws WalletUserException */
	@Override
	public boolean login(String username, String userpass) throws WalletUserException {
		myLogger.info("-----------login------------");
		boolean status = false;
		Query query = entityManager.createQuery(QueryUtil.CHECK_LOGIN);
		// setting the query dynamic parameter
		query.setParameter("uname", username);
		query.setParameter("upass", userpass);
		// fetching only 1 result
		query.setMaxResults(1);
		WalletUser walletUser = (WalletUser) query.getSingleResult();
		myLogger.info(" WalletUser login ..... " + walletUser);
		if (walletUser != null) {
			status = true;
			myLogger.error(" WalletUser login failed!! " + walletUser);
		}
		return status;
	}

	/*
	 * This is the findUserById method which search WalletUser by its userId
	 * @param userId
	 * @return WalletUser.
	 * @throws WalletUserException */
	@Override
	public WalletUser findUserById(BigInteger userId) throws WalletUserException {
		myLogger.info("-----------findUserById------------");
		WalletUser 	walletUser = entityManager.find(WalletUser.class, userId);	
		if (walletUser != null) {
			myLogger.error(" WalletUser findUserById is null..userId:"+userId+".. " + walletUser);
		}
		myLogger.info(" WalletUser findUserById is found with..userId:"+userId+".. " + walletUser);
		return walletUser;
	}
}