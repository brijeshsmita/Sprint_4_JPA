/**
 * 
 */
package com.capgemini.paymentwallet.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.paymentwallet.dao.WalletUserDao;
import com.capgemini.paymentwallet.dao.WalletUserDaoImpl;
import com.capgemini.paymentwallet.exception.WalletUserException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.util.MyLoggerUtil;

/**
 * @author smitkuma
 *
 */
public class WalletUserServiceImpl implements WalletUserService {
	// prep work create instance of dao layer
	private static WalletUserDao walletUserDao;
	private static JpaTransactionService jpaTransactionService;
	private static TxHistoryService txHistoryService;
	private static Logger myLogger;
	/*
	 * static block to declare logger and create the instance of DaoImpl
	 */

	static {
		MyLoggerUtil.configure();
		myLogger = Logger.getLogger("WalletAccountServiceImpl.class");
		walletUserDao = new WalletUserDaoImpl();
		if (walletUserDao != null)
			myLogger.info("walletUserDao instance created at WalletAccountServiceImpl");
		else
			myLogger.error("walletUserDao instance not created at WalletAccountServiceImpl");
		jpaTransactionService = new JpaTransactionServiceImpl();
		if (jpaTransactionService != null)
			myLogger.info("jpaTransactionService instance created at WalletAccountServiceImpl");
		else
			myLogger.error("jpaTransactionService instance not created at WalletAccountServiceImpl");
		
		txHistoryService = new TxHistoryServiceImpl();
		if (txHistoryService != null)
			myLogger.info("txHistoryService instance created at WalletAccountServiceImpl");
		else
			myLogger.error("txHistoryService instance not created at WalletAccountServiceImpl");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.WalletAccountService#register(com.
	 * capgemini.paymentwallet.model.WalletUser)
	 * This is the register method which create a new user and wallet account	 * 
	 * @param walletUser 
	 * @param accBalance.	 
	 * @return WalletUser.
	 * @throws PaymentWalletException */ 
	@Override
	public WalletUser register(WalletUser walletUser, BigDecimal accBalance) throws WalletUserException {
		jpaTransactionService.beginTx();
		// Wallet Account
		WalletAccount walletAccount = new WalletAccount();
		walletAccount.setAccBalance(accBalance);
		walletAccount.setWalletUser(walletUser);
		walletAccount.setAccOpenDateTime(LocalDateTime.now());
			walletAccount.setWalletUser(walletUser);
		//setting WalletAccount to WalletUser
		walletUser.setWalletAccount(walletAccount);
		walletUser = walletUserDao.register(walletUser, accBalance);
		// Transaction History
		List<TransactionHistory> transactionHistories = txHistoryService.addTransactionHistory(walletAccount, "Account Open",
				"Opening the new Wallet Account", accBalance.doubleValue(), 0.0);
		walletAccount.setTransactionHistories(transactionHistories);			
		jpaTransactionService.commitTx();
		return walletUser;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.WalletAccountService#login(com.capgemini
	 * .paymentwallet.model.WalletUser)
	 * This is the login method which authenticate user
	 * @param username 
	 * @param userpass.	 
	 * @return boolean.
	 * @throws PaymentWalletException */
	@Override
	public boolean login(String username, String userpass) throws WalletUserException {
		jpaTransactionService.beginTx();
		boolean status = walletUserDao.login(username, userpass);
		jpaTransactionService.commitTx();
		return status;
	}
	/*
	 * This is the findUserById method which search WalletUser by its userId
	 * @param userId
	 * @return WalletUser.
	 * @throws PaymentWalletException*/
	@Override
	public WalletUser findUserById(BigInteger userId) throws WalletUserException {
		jpaTransactionService.beginTx();
		WalletUser walletUser = walletUserDao.findUserById(userId);
		jpaTransactionService.commitTx();
		return walletUser;
	}
	
	public static WalletUserDao getPaymentWalletDao() {
		return walletUserDao;
	}

	public static void setPaymentWalletDao(WalletUserDao walletUserDao) {
		WalletUserServiceImpl.walletUserDao = walletUserDao;
	}

}
