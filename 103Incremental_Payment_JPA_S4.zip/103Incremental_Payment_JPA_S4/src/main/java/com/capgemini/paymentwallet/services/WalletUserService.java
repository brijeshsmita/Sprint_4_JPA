/**
 * 
 */
package com.capgemini.paymentwallet.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import com.capgemini.paymentwallet.exception.WalletUserException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public interface WalletUserService {
	/*	 * This is the register method which create a new user and wallet account	 * 
	 * @param walletUser 
	 * @param accBalance.	 
	 * @return WalletUser.
	 * @throws WalletUserException */
	public WalletUser register (WalletUser walletUser,BigDecimal accBalance) throws WalletUserException;
	/* * This is the login method which authenticate user
	 * @param username 
	 * @param userpass.	 
	 * @return boolean.
	 * @throws WalletUserException */
	public boolean login (String username, String userpass)throws WalletUserException;
	/*
	 * This is the findUserById method which search WalletUser by its userId
	 * @param userId
	 * @return WalletUser.
	 * @throws WalletUserException */
	public WalletUser findUserById(BigInteger userId) throws WalletUserException;
	}
