/**
 * 
 */
package com.capgemini.paymentwallet.services;

import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;

import com.capgemini.paymentwallet.dao.JpaTransactionDao;
import com.capgemini.paymentwallet.dao.JpaTransactionDaoImpl;
import com.capgemini.paymentwallet.exception.JpaTransactionException;
import com.capgemini.paymentwallet.util.MyLoggerUtil;

/**
 * @author smitkuma
 *
 */
public class JpaTransactionServiceImpl implements JpaTransactionService {
	// prep work create instance of dao layer
	private static JpaTransactionDao jpaTransactionDao;
	private static Logger myLogger;
	/*
	 * static block to declare logger and create the instance of DaoImpl
	 */

	static {
		MyLoggerUtil.configure();
		myLogger = Logger.getLogger("WalletAccountServiceImpl.class");
	
		jpaTransactionDao = new JpaTransactionDaoImpl();
		if (jpaTransactionDao != null)
			myLogger.info("jpaTransactionDao instance created at WalletAccountServiceImpl");
		else
			myLogger.error("jpaTransactionDao instance not created at WalletAccountServiceImpl");
	}
	
	/*
	 *  This is the beginTx method which begins the transaction
	 * @param EntityTransaction
	 * @return nothing
	 * */
	@Override
	public EntityTransaction beginTx()  throws JpaTransactionException{
		return jpaTransactionDao.beginTx();
	}
	/*
	 *  This is the commitTx method which commits the transaction
	 * @param EntityTransaction
	 * @return nothing
	 * */
	@Override
	public EntityTransaction commitTx() throws JpaTransactionException {
		return jpaTransactionDao.commitTx();
	}
	/*
	 *  This is the rollbackTx method which rollback the transaction
	 * @param EntityTransaction
	 * @return nothing
	 * */
	@Override
	public EntityTransaction rollbackTx() throws JpaTransactionException {
		return jpaTransactionDao.rollbackTx();
	}

}
