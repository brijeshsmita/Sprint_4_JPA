/**
 * 
 */
package com.capgemini.paymentwallet.model;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author smitkuma
 * 
 */
@Entity
@Table(name="WALLET_USER")
public class WalletUser implements Serializable {
	private static final long serialVersionUID = -3946091634178333943L;

	@GeneratedValue
	@Column(name="USER_ID")
	@Id
	private BigInteger userId;	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ACC_ID",referencedColumnName = "ACC_ID")
	private WalletAccount walletAccount ;
	
	private String username;	
	private String userpass;
	private BigInteger pin;
	@Column(name="FIRST_NAME")
	private String firstName ;
	@Column(name="LAST_NAME")	
	private String lastName ;
	@Column(name="MOBILE_NO")
	private BigInteger mobileNo ;
	private String address ;	
	
	public WalletUser() {
		super();
	}
	public WalletUser(String username, String userpass, BigInteger pin, String firstName, String lastName, BigInteger mobileNo,
			String address) {
		super();
		this.username = username;
		this.userpass = userpass;
		this.pin = pin;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.address = address;
	}
	@Override
	public String toString() {
		return "WalletUser [userId=" + userId + ", username=" + username + ", userpass=" + userpass + ", pin=" + pin
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", mobileNo=" + mobileNo + ", address="
				+ address + ", walletAccount=" + walletAccount + "]";
	}
	public BigInteger getUserId() {
		return userId;
	}
	public void setUserId(BigInteger userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public BigInteger getPin() {
		return pin;
	}
	public void setPin(BigInteger pin) {
		this.pin = pin;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public BigInteger getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(BigInteger mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getUserpass() {
		return userpass;
	}
	public void setUserpass(String userpass) {
		this.userpass = userpass;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public WalletAccount getWalletAccount() {
		return walletAccount;
	}
	public void setWalletAccount(WalletAccount walletAccount) {
		this.walletAccount = walletAccount;
	}
	@Override
	public int hashCode() {
		return userId.intValue();
	}
	@Override
	public boolean equals(Object obj) {
		boolean status= false;
		if(obj!=null)
			status= this.hashCode()==obj.hashCode();
		return status;
	}
}
