/**
 * 
 */
package com.capgemini.paymentwallet.dao;

import javax.persistence.EntityTransaction;

import com.capgemini.paymentwallet.exception.JpaTransactionException;

/**
 * @author smitkuma
 *
 */
public interface JpaTransactionDao {
	/*
	 *  This is the beginTx method which begins the transaction
	 * @param EntityTransaction
	 * @return nothing
	 **/
	
	public EntityTransaction beginTx() throws JpaTransactionException;
	/*
	 *  This is the commitTx method which commits the transaction
	 * @param EntityTransaction
	 * @return nothing
	 * @ */
	
	public EntityTransaction commitTx()throws JpaTransactionException;
	/*
	 *  This is the rollbackTx method which rollback the transaction
	 * @param EntityTransaction
	 * @return nothing
	 * @ */
	
	public EntityTransaction rollbackTx()throws JpaTransactionException;
}
