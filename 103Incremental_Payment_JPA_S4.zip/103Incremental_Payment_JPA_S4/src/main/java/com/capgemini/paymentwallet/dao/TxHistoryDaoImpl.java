/**
 * 
 * @throws TxHistoryException */
package com.capgemini.paymentwallet.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.capgemini.paymentwallet.exception.TxHistoryException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.util.ErrorMessageUtil;
import com.capgemini.paymentwallet.util.JPAUtil;
import com.capgemini.paymentwallet.util.MyLoggerUtil;
import com.capgemini.paymentwallet.util.QueryUtil;

/**
 * @author smitkuma
 *
 * @throws TxHistoryException */
public class TxHistoryDaoImpl implements TxHistoryDao {
	private static EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
	private static Logger myLogger;
	/*
	 * static block to configure logger and obtain entity manager factory object
	 */
	static {

		MyLoggerUtil.configure();
		myLogger = Logger.getLogger(TxHistoryDaoImpl.class);
		entityManagerFactory = JPAUtil.getEntityManagerFactory();
		myLogger.info("entityManagerFactory Obtained!!");
	}
/*
 * constructor to obtain entityManager object
 */
	public TxHistoryDaoImpl() {
		entityManager = entityManagerFactory.createEntityManager();
	}

	
	/*
	 *  This is the addTransactionHistory method which add current wallet acc tx to the exiting wallet account tx
	 * @param walletAccount
	 * @param txType
	 * @param txDescription
	 * @param amtCredited
	 * @param amtDebited
	 * @return List<TransactionHistory>.
	 * @throws TxHistoryException */
	@Override
	public List<TransactionHistory> addTransactionHistory(WalletAccount walletAccount, String txType,
			String txDescription, double amtCredited, double amtDebited) throws TxHistoryException {
		myLogger.info("-----------addTransactionHistory------------"+walletAccount.getAccId());
		TransactionHistory txHistory = new TransactionHistory();
		List<TransactionHistory> txHistories = viewAllTxHistory(walletAccount.getAccId());
		if (txHistories != null) {
			LocalDateTime txDateTime = LocalDateTime.now();
			
			txHistory.setWalletAccount(walletAccount);
			txHistory.setAmtCredited(BigDecimal.valueOf(amtCredited));
			txHistory.setAmtDebited(BigDecimal.valueOf(amtDebited));
			txHistory.setTxDateTime(txDateTime);
			txHistory.setTxType(txType);
			txHistory.setTxDescription(txDescription);
			// entityManager.persist(txHistory);
			myLogger.info("-----------txHistory------------" + txHistory);
			txHistories.add(txHistory);

		} else {
			myLogger.error(ErrorMessageUtil.ADD_TX_HIS_ERROR + txHistory);
			return null;
		}
		return txHistories;
	}
	/*
	 *  This is the viewtxHistory method which provide the list of all the tx of the specific account for specific dates
	 * @param accId
	 * @param toDate
	 * @param fromDate
	 * @return List<TransactionHistory>.
	 * @throws TxHistoryException */
	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionHistory> viewtxHistory(BigInteger accId, LocalDateTime toDate, LocalDateTime fromDate)
			throws TxHistoryException {
		myLogger.info("-----------viewtxHistory------------");
		WalletAccount walletAccount = entityManager.find(WalletAccount.class, accId);
		List<TransactionHistory> txHistories = new ArrayList<>();

		Query query = entityManager.createQuery(QueryUtil.VIEW_TX_HIS);
		query.setParameter("walletAccount", walletAccount);
		txHistories = query.getResultList();
		myLogger.info("Tx : " + txHistories);
		List<TransactionHistory> retTxHistories = new ArrayList<TransactionHistory>();
		for (int i = 0; i < txHistories.size(); i++) {
			if (txHistories.get(i).getTxDateTime() != null
					&& txHistories.get(i).getTxDateTime().compareTo(fromDate) >= 0
					&& txHistories.get(i).getTxDateTime().compareTo(toDate) <= 0) {
				retTxHistories.add(txHistories.get(i));
			} else {
				myLogger.error(ErrorMessageUtil.VIEW_TX_HIS_ERROR);
			}
		}
		return txHistories;
	}
	/*
	 *  This is the viewAllTxHistory method which provide the list of all the tx of the specific account
	 * @param accId
	 * @return List<TransactionHistory>.
	 * @throws TxHistoryException */
	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionHistory> viewAllTxHistory(BigInteger accId) throws TxHistoryException {
		myLogger.info("-----------viewAllTxHistory------------");
			Query query = entityManager.createQuery(QueryUtil.VIEW_TX_HIS);
			query.setParameter("accId", accId);
			List<TransactionHistory> txHistories = query.getResultList();
			myLogger.info("Tx : " + txHistories);

		if(txHistories==null) {
			myLogger.error(ErrorMessageUtil.VIEW_ALL_TX_HIS_ERROR + txHistories);
		}
		return txHistories;
	}
}