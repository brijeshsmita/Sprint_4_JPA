/**
 * 
 */
package com.capgemini.paymentwallet.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author smitkuma
 *
 */
@Entity
@Table(name="WALLET_ACCOUNT")
public class WalletAccount implements Serializable{
	private static final long serialVersionUID = -3946091634178111941L;

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ACC_ID")
	@Id
	private BigInteger accId;	

	@OneToOne(cascade = CascadeType.ALL,mappedBy = "walletAccount")
	private WalletUser walletUser;
	
	@Column(name="ACC_BALANCE")
	private BigDecimal accBalance;
	
	@Column(name="ACC_OPEN_DATETIME", nullable = false)
	//@Temporal(TemporalType.TIMESTAMP)
	//@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDateTime accOpenDateTime ;

	@OneToMany(mappedBy = "walletAccount",cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private List<TransactionHistory> transactionHistories;
	
	public WalletAccount( WalletUser walletUser, BigDecimal accBalance, LocalDateTime accOpenDateTime) {
		super();
		this.walletUser = walletUser;
		this.accBalance = accBalance;
		this.accOpenDateTime = accOpenDateTime;
	}

	public WalletAccount() {
		// TODO Auto-generated constructor stub
	}

	public BigInteger getAccId() {
		return accId;
	}

	public void setAccId(BigInteger accId) {
		this.accId = accId;
	}

	public WalletUser getWalletUser() {
		return walletUser;
	}

	public void setWalletUser(WalletUser walletUser) {
		this.walletUser = walletUser;
	}

	public BigDecimal getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(BigDecimal accBalance) {
		this.accBalance = accBalance;
	}

	public LocalDateTime getAccOpenDateTime() {
		return accOpenDateTime;
	}

	public void setAccOpenDateTime(LocalDateTime accOpenDateTime) {
		this.accOpenDateTime = accOpenDateTime;
	}

	public List<TransactionHistory> getTransactionHistories() {
		return transactionHistories;
	}

	public void setTransactionHistories(List<TransactionHistory> transactionHistories) {
		this.transactionHistories = transactionHistories;
	}

	@Override
	public String toString() {
		return "WalletAccount [accId=" + accId + ", accBalance=" + accBalance
				+ ", accOpenDateTime=" + accOpenDateTime + ", transactionHistories=" + transactionHistories + "]";
	}

	@Override
	public int hashCode() {		
		return this.accId.intValue();
	}

	@Override
	public boolean equals(Object obj) {
		boolean status= false;
		if(obj!=null)
			status= this.hashCode()==obj.hashCode();
		return status;
	}
}
