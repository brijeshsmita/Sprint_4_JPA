/**
 * 
 */
package com.capgemini.paymentwallet.exception;

/**
 * @author smitkuma
 *
 */
@SuppressWarnings("serial")
public class JpaTransactionException extends RuntimeException {

	/**
	 * 
	 */
	public JpaTransactionException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public JpaTransactionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
