/**
 * 
 * @throws PaymentWalletException */
package com.capgemini.paymentwallet.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.util.ErrorMessageUtil;
import com.capgemini.paymentwallet.util.JPAUtil;
import com.capgemini.paymentwallet.util.MyLoggerUtil;
import com.capgemini.paymentwallet.util.QueryUtil;

/**
 * @author smitkuma
 *
 * @throws PaymentWalletException */
public class WalletAccountDaoImpl implements WalletAccountDao {
	private static EntityManagerFactory entityManagerFactory;
	private EntityManager entityManager;
	private static Logger myLogger;
	private EntityTransaction transaction;
	/*
	 * static block to configure logger and obtain entity manager factory object
	 */
	static {

		MyLoggerUtil.configure();
		myLogger = Logger.getLogger(WalletAccountDaoImpl.class);
		entityManagerFactory = JPAUtil.getEntityManagerFactory();
		if(entityManagerFactory!=null)
			myLogger.info("entityManagerFactory Obtained!!");
		else
			myLogger.error("entityManagerFactory NOT Obtained!!");

	}
/*
 * constructor to obtain entityManager object
 */
	public WalletAccountDaoImpl() {

		entityManager = entityManagerFactory.createEntityManager();
		transaction = entityManager.getTransaction();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.WalletAccountService#addMoney(java.lang
	 * .BigInteger, java.lang.BigInteger, java.lang.BigDecimal)
	 * This is the addMoney method which deposit money to the WalletAccount
	 * @param accId
	 * @param amount
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	@Override
	public WalletAccount addMoney(BigInteger accId, double amount) throws PaymentWalletException {
		myLogger.info("-----------addMoney------------amount : " + amount + "------- to account ----- " + accId);
		WalletAccount walletAccount = viewWallet(accId);
		System.err.println("&&&&&&&&&&&&& -----addMoney-----" + walletAccount);
		if (walletAccount != null) {
			// if walletAccount exists then adding money to the existing wallet acc.
			double updatedAmount = amount + walletAccount.getAccBalance().doubleValue();
			walletAccount.setAccBalance(BigDecimal.valueOf(updatedAmount));
			System.err.println("Adding Money to the wallet : " + walletAccount);
			walletAccount = entityManager.merge(walletAccount);
			myLogger.info("&&&&&&&&&&&&& -----addMoney-----" + walletAccount);
			System.err.println("&&&&&&&&&&&&& -----addMoney-----" + walletAccount);

		} else {
			myLogger.error(ErrorMessageUtil.ADD_MONEY_ERROR + walletAccount);
		}
		return walletAccount;
	}
/*
 *  This is the checkBalance method which returns balance form the specific WalletAccount
	 * @param accId
	 * @return BigDecimal.
 * @throws PaymentWalletException */
	@Override
	public BigDecimal checkBalance(BigInteger accId) throws PaymentWalletException {
		myLogger.info("-----------checkBalance------------");
		WalletAccount walletAccount = viewWallet(accId);
		BigDecimal accBal = new BigDecimal(0);
		if (walletAccount != null)  {			
			accBal = walletAccount.getAccBalance();
			myLogger.info(" -----checkBalance of : "+accId+"-------------------Balance " + accBal);
		}else {
			myLogger.error(ErrorMessageUtil.CHECK_BAL_ERROR + walletAccount);
		}
		return accBal;
	}
	/*
	 *  This is the viewWallet method which returns WalletAccount for the specific accId
	 * @param accId
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	@Override
	public WalletAccount viewWallet(BigInteger accId) throws PaymentWalletException {
		myLogger.info("-----------viewWallet------------");
		WalletAccount walletAccount = entityManager.find(WalletAccount.class, accId);
		myLogger.info("viewWallet for accId : " + accId);
		if (walletAccount == null)  {		
			myLogger.error(ErrorMessageUtil.VIEW_WALLET_ERROR + walletAccount);
		}
		return walletAccount;
	}
	/*
	 *  This is the viewWalletByUserId method which returns WalletAccount for the specific userId
	 * @param userId
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	@Override
	public WalletAccount viewWalletByUserId(BigInteger userId) throws PaymentWalletException {
		myLogger.info("-----------viewWalletByUserId---------userId---" + userId);

		Query query = entityManager.createQuery(QueryUtil.VIEW_WALLET_BY_USERID);
		// setting the query dynamic parameter
		query.setParameter("userId", userId);
		// fetching only 1 result
		query.setMaxResults(1);
		WalletAccount walletAccount = (WalletAccount) query.getSingleResult();
		myLogger.info("viewWalletByUserId : walletaccout : " + walletAccount);
		if (walletAccount == null) {
			myLogger.error(ErrorMessageUtil.VIEW_WALLET_BY_ID_ERROR + walletAccount);
		}
		return walletAccount;
	}
	/*
	 *  This is the fundTransfer method which transfer amt from 1 WalletAccount to another
	 * @param fromAccId
	 * @param toAccId
	 * @param amount
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	@Override
	public WalletAccount fundTransfer(BigInteger fromAccId, BigInteger toAccId, double amount)
			throws PaymentWalletException {
		WalletAccount accBalFrom = viewWallet(fromAccId);
		WalletAccount accBalTo = viewWallet(toAccId);
		myLogger.info("-----------fundTransfer------------accBalFrom : " + accBalFrom + "\n accBalTo: " + accBalTo);
		if (accBalFrom != null && accBalTo != null) {
			double amtBalFrom = accBalFrom.getAccBalance().doubleValue();
			double amtBalTo = accBalTo.getAccBalance().doubleValue();
			myLogger.info("accBalFrom : " + amtBalFrom + " ,accBalTo :  " + amtBalTo + " \n accBalFrom>amount))"
					+ (amtBalFrom > amount));
			if (amtBalFrom > amount) {// if accBal is >=amount the fund transfer can
										// happen
				myLogger.info("-----------accBalFrom>amount------------");
				// add amount to the toAcc
				// and deduct amt form the FromAcc
				amtBalFrom -= amount;
				amtBalTo += amount;
				List<TransactionHistory> transactionHistoriesFrom = addTransactionHistory(accBalFrom, "Fund transfer",
						"Fund transfered to " + toAccId, 0, amount);
				accBalFrom.setTransactionHistories(transactionHistoriesFrom);
				accBalFrom.setAccBalance(BigDecimal.valueOf(amtBalFrom));

				List<TransactionHistory> transactionHistoriesTo = addTransactionHistory(accBalTo, "Fund transfer",
						"Fund transfered from " + fromAccId, amount, 0);
				accBalTo.setTransactionHistories(transactionHistoriesTo);
				accBalTo.setAccBalance(BigDecimal.valueOf(amtBalTo));
				myLogger.info("****************accBalFrom : " + accBalFrom);
				myLogger.info("****************accBalTo : " + accBalTo);

				entityManager.merge(accBalFrom);
				entityManager.merge(accBalTo);

			} else {
				myLogger.error("Insufficient Balance for Fund transfer...." + amtBalFrom);
			}
		} else {
			myLogger.error("Account does not exists...." + accBalFrom);
		}
		myLogger.info("-----------fundTransfer------------accBalFrom : " + accBalFrom + "\n accBalTo: " + accBalTo);
		return accBalFrom;
	}
	/*
	 *  This is the addTransactionHistory method which add current wallet acc tx to the exiting wallet account tx
	 * @param walletAccount
	 * @param txType
	 * @param txDescription
	 * @param amtCredited
	 * @param amtDebited
	 * @return List<TransactionHistory>.
	 * @throws PaymentWalletException */
	public List<TransactionHistory> addTransactionHistory(WalletAccount walletAccount, String txType,
			String txDescription, double amtCredited, double amtDebited) throws PaymentWalletException {
		myLogger.info("-----------addTransactionHistory------------");
		TransactionHistory txHistory = new TransactionHistory();
		List<TransactionHistory> txHistories = walletAccount.getTransactionHistories();
		if (txHistories != null) {

			LocalDateTime txDateTime = LocalDateTime.now();
			txHistory.setAmtCredited(BigDecimal.valueOf(amtCredited));
			txHistory.setAmtDebited(BigDecimal.valueOf(amtDebited));
			txHistory.setTxDateTime(txDateTime);
			txHistory.setTxType(txType);
			txHistory.setTxDescription(txDescription);
			// entityManager.persist(txHistory);
			myLogger.info("-----------txHistory------------" + txHistory);
			txHistories.add(txHistory);

		} else {
			myLogger.error(ErrorMessageUtil.ADD_TX_HIS_ERROR + txHistory);
			return null;
		}
		return txHistories;
	}
	
}