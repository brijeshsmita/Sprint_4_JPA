/**
 * 
 */
package com.capgemini.paymentwallet.util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * @author smitkuma
 *
 */
public class JPAUtil {
	private JPAUtil() {}
	private static EntityManagerFactory entityManagerFactory;
	static {
		entityManagerFactory = Persistence.createEntityManagerFactory("JPA_PU");
	}
	public static EntityManagerFactory getEntityManagerFactory() {
		return entityManagerFactory;
	}
	public static void setEntityManagerFactory(EntityManagerFactory entityManagerFactory) {
		JPAUtil.entityManagerFactory = entityManagerFactory;
	}
	public static void closeEntityManagerFactory() {
			entityManagerFactory.close();
	}
}
