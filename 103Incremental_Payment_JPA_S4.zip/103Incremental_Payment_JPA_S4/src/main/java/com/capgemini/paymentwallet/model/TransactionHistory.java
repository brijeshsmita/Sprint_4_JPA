/**
 * 
 */
package com.capgemini.paymentwallet.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author smitkuma
 *
 */
@Entity
@Table(name = "TRANSACTION_HISTORY")
public class TransactionHistory implements Serializable {
	private static final long serialVersionUID = -3946091644448333943L;

	@Id
	@Column(name = "TX_ID")
	@GeneratedValue
	private BigInteger txId;

	@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER )
	@JoinColumn(name = "ACC_ID",referencedColumnName = "ACC_ID")
	private WalletAccount walletAccount;

	@Column(name = "TX_DATE_TIME")
	//@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentLocalDate")
	private LocalDateTime txDateTime;

	@Column(name = "TX_TYPE")
	private String txType;

	@Column(name = "AMT_CREDITED")
	private BigDecimal amtCredited;

	@Column(name = "AMT_DEBITED")
	private BigDecimal amtDebited;

	@Column(name = "TX_DESCRIPTION")
	private String txDescription;

	public TransactionHistory() {
		// TODO Auto-generated constructor stub
	}

	public TransactionHistory(WalletAccount walletAccount, LocalDateTime txDateTime, String txType,
			BigDecimal amtCredited, BigDecimal amtDebited, String txDescription) {
		super();
		this.walletAccount = walletAccount;
		this.txDateTime = txDateTime;
		this.txType = txType;
		this.amtCredited = amtCredited;
		this.amtDebited = amtDebited;
		this.txDescription = txDescription;
	}

	public BigInteger getTxId() {
		return txId;
	}

	public void setTxId(BigInteger txId) {
		this.txId = txId;
	}

	public WalletAccount getWalletAccount() {
		return walletAccount;
	}

	public void setWalletAccount(WalletAccount walletAccount) {
		this.walletAccount = walletAccount;
	}

	public LocalDateTime getTxDateTime() {
		return txDateTime;
	}

	public void setTxDateTime(LocalDateTime txDateTime) {
		this.txDateTime = txDateTime;
	}

	public String getTxType() {
		return txType;
	}

	public void setTxType(String txType) {
		this.txType = txType;
	}

	public BigDecimal getAmtCredited() {
		return amtCredited;
	}

	public void setAmtCredited(BigDecimal amtCredited) {
		this.amtCredited = amtCredited;
	}

	public BigDecimal getAmtDebited() {
		return amtDebited;
	}

	public void setAmtDebited(BigDecimal amtDebited) {
		this.amtDebited = amtDebited;
	}

	public String getTxDescription() {
		return txDescription;
	}

	public void setTxDescription(String txDescription) {
		this.txDescription = txDescription;
	}

	@Override
	public String toString() {
		return "TransactionHistory [txId=" + txId + ",txDateTime=" + txDateTime
				+ ", txType=" + txType + ", amtCredited=" + amtCredited + ", amtDebited=" + amtDebited
				+ ", txDescription=" + txDescription + "]";
	}

	@Override
	public int hashCode() {
		return txId.intValue();
	}

	@Override
	public boolean equals(Object obj) {
		boolean status = false;
		if (obj != null)
			status = this.hashCode() == obj.hashCode();
		return status;
	}
}
