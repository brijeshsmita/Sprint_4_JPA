/**
 * 
 */
package com.capgemini.paymentwallet.exception;

/**
 * @author smitkuma
 *
 */
public class PaymentWalletException extends RuntimeException {

	public PaymentWalletException() {
		super();
	}
	public PaymentWalletException(String message) {
		super(message);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -7900677380899033365L;

}
