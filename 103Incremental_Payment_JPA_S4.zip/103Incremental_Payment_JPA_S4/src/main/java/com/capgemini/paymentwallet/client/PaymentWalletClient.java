/**
 * 
 */
package com.capgemini.paymentwallet.client;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.services.TxHistoryService;
import com.capgemini.paymentwallet.services.TxHistoryServiceImpl;
import com.capgemini.paymentwallet.services.WalletAccountService;
import com.capgemini.paymentwallet.services.WalletAccountServiceImpl;
import com.capgemini.paymentwallet.services.WalletUserService;
import com.capgemini.paymentwallet.services.WalletUserServiceImpl;
import com.capgemini.paymentwallet.util.JPAUtil;
import com.capgemini.paymentwallet.util.MyLoggerUtil;

/**
 * @author smitkuma
 *
 */
public class PaymentWalletClient {
	private static TxHistoryService txHistoryService;
	private static WalletAccountService walletAccountService;
	private static WalletUserService walletUserService;
	private static Logger myLogger;
	static {
		MyLoggerUtil.configure();
		myLogger = Logger.getLogger("PaymentWalletClient.class");
		walletAccountService = new WalletAccountServiceImpl();
		walletUserService = new WalletUserServiceImpl();
		txHistoryService = new TxHistoryServiceImpl();
	}

	private PaymentWalletClient() {

	}

	public static void main(String[] args) throws PaymentWalletException {

		// creating user and his WalletAccount by calling both entity setter method
		// as we have 1 to 1 association

		WalletUser u1 = new WalletUser("ram", "ram", BigInteger.valueOf(1112), "Ram", "Singh",
				BigInteger.valueOf(9870004443L), "Pune");

		WalletAccount walletAccount1 = new WalletAccount();
		walletAccount1.setAccBalance(BigDecimal.valueOf(10000.00));
		walletAccount1.setWalletUser(u1);
		walletAccount1.setAccOpenDateTime(LocalDateTime.now());

		WalletUser registeredUser1 = walletUserService.register(u1, BigDecimal.valueOf(10000.00));
		myLogger.info("Registered User 1: " + registeredUser1);

		// find user by userId

		BigInteger fromUserId = registeredUser1.getUserId();
		WalletUser fromFoundUser = walletUserService.findUserById(fromUserId);
		myLogger.info("fromFoundUser : " + fromFoundUser);

		// add money to walletAccount 1
		BigInteger fromAccId = fromFoundUser.getWalletAccount().getAccId();
		WalletAccount updatedWalletAcc = walletAccountService.addMoney(fromAccId, 2000.00);
		myLogger.info("**** After AddMony updatedWalletAcc : " + updatedWalletAcc);

		WalletAccount walletAccount2 = new WalletAccount();
		WalletUser u2 = new WalletUser("raj", "raj", BigInteger.valueOf(1234), "Raj", "Mathur",
				BigInteger.valueOf(9870001144L), "Pune");
		walletAccount2.setAccBalance(BigDecimal.valueOf(10000.00));
		walletAccount2.setWalletUser(u2);
		walletAccount2.setAccOpenDateTime(LocalDateTime.now());
		u2.setWalletAccount(walletAccount2);

		WalletUser registeredUser2 = walletUserService.register(u2, BigDecimal.valueOf(10000.00));
		myLogger.info("Registered User 2: " + registeredUser2);

		// login

		boolean status = walletUserService.login("mona", "mona");
		if (status) {
			myLogger.info("hello ," + u1.getFirstName() + " Login Successfull status : " + status);
		} else {
			myLogger.error("Invalid Credentials ");
		}

		WalletUser toFoundUser = walletUserService.findUserById(BigInteger.valueOf(2));
		myLogger.info("toFoundUser : " + toFoundUser);

		// fund Transfer from acc to To acc
		BigInteger toAccId = toFoundUser.getWalletAccount().getAccId();
		walletAccountService.fundTransfer(fromAccId, toAccId, 4000);

		// view transaction history for an account from and to specific date
		List<TransactionHistory> txHistories = txHistoryService.viewtxHistory(fromAccId,
				LocalDateTime.of(2019, 9, 10, 0, 0, 0), LocalDateTime.of(2019, 9, 11, 0, 0, 0));
		myLogger.info("Tx Histories for fromAccId : " + fromAccId);

		for (TransactionHistory tx : txHistories) {
			myLogger.info(tx);
		}

		// view transaction history for an account from and to specific date
		txHistories = txHistoryService.viewtxHistory(toAccId, LocalDateTime.of(2019, 9, 10, 0, 0, 0),
				LocalDateTime.of(2019, 9, 11, 0, 0, 0));
		myLogger.info("Tx Histories for toAccId : " + toAccId);
		for (TransactionHistory tx : txHistories) {
			myLogger.info(tx);
		}

		// check bal by accId

		BigDecimal balance = walletAccountService.checkBalance(BigInteger.valueOf(1001));
		myLogger.info("balance of acc 1001 before adding money : " + balance);

		WalletAccount updatedWalletAcc1 = walletAccountService.addMoney(BigInteger.valueOf(1001), 2000.00);
		myLogger.info("**** After AddMony updatedWalletAcc : " + updatedWalletAcc1);

		// check bal by accId

		balance = walletAccountService.checkBalance(BigInteger.valueOf(1001));
		myLogger.info("balance of acc 1001  after adding money : " + balance);

		// find user by userId

		fromFoundUser = walletUserService.findUserById(BigInteger.valueOf(2));
		myLogger.info("fromFoundUser : " + fromFoundUser);

		JPAUtil.closeEntityManagerFactory();
	}

}
