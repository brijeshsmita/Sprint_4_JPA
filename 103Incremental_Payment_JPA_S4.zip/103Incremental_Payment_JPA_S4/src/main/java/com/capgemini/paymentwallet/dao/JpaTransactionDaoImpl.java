/**
 * 
 * */
package com.capgemini.paymentwallet.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.apache.log4j.Logger;

import com.capgemini.paymentwallet.exception.JpaTransactionException;
import com.capgemini.paymentwallet.util.JPAUtil;
import com.capgemini.paymentwallet.util.MyLoggerUtil;

/**
 * @author smitkuma
 *
 * */
public class JpaTransactionDaoImpl implements JpaTransactionDao {
	private EntityManager entityManager;
	private EntityTransaction transaction;
	private static EntityManagerFactory entityManagerFactory;
	private static Logger myLogger;
	/*
	 * static block to configure logger and obtain entity manager factory object
	 */
	static {

		MyLoggerUtil.configure();
		myLogger = Logger.getLogger(WalletUserDaoImpl.class);
		entityManagerFactory = JPAUtil.getEntityManagerFactory();
		myLogger.info("entityManagerFactory Obtained!!");

	}

/*
 * constructor to obtain entityManager and transaction object
 */
	public JpaTransactionDaoImpl(){

		entityManager = entityManagerFactory.createEntityManager();
		transaction = entityManager.getTransaction();
	}
	/*
	 *  This is the beginTx method which begins the transaction
	 * @param EntityTransaction
	 * @return nothing
	 * */
	@Override
	public EntityTransaction beginTx() throws JpaTransactionException {
		if (!transaction.isActive()) {
			transaction.begin();
			myLogger.info("transaction begin!!");
		}
		return transaction;
	}
	/*
	 *  This is the commitTx method which commits the transaction
	 * @param EntityTransaction
	 * @return nothing
	 * */
	@Override
	public EntityTransaction commitTx() throws JpaTransactionException {
		if (transaction.isActive()) {
			transaction.commit();
			myLogger.info("transaction commited!!");
		}
		return transaction;
	}
	/*
	 *  This is the rollbackTx method which rollback the transaction
	 * @param EntityTransaction
	 * @return nothing
	 * */
	@Override
	public EntityTransaction rollbackTx() throws JpaTransactionException {
		if (transaction.isActive()) {
			transaction.rollback();
			myLogger.info("transaction rollbacked!!");
		}
		return transaction;
	}

}