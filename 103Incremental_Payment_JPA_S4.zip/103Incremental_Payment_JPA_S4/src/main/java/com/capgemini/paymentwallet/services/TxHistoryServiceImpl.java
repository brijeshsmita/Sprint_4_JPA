/**
 * 
 */
package com.capgemini.paymentwallet.services;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.paymentwallet.dao.JpaTransactionDaoImpl;
import com.capgemini.paymentwallet.dao.TxHistoryDao;
import com.capgemini.paymentwallet.dao.TxHistoryDaoImpl;
import com.capgemini.paymentwallet.exception.TxHistoryException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.util.MyLoggerUtil;

/**
 * @author smitkuma
 *
 */
public class TxHistoryServiceImpl implements TxHistoryService {
	// prep work create instance of dao layer
	private static TxHistoryDao txHistoryDao;
	private static JpaTransactionService jpaTransactionService;
	private static Logger myLogger;
	/*
	 * static block to declare logger and create the instance of DaoImpl
	 */

	static {
		MyLoggerUtil.configure();
		myLogger = Logger.getLogger("WalletAccountServiceImpl.class");
		txHistoryDao = new TxHistoryDaoImpl();
		if (txHistoryDao != null)
			myLogger.info("txHistoryDao instance created at WalletAccountServiceImpl");
		else
			myLogger.error("txHistoryDao instance not created at WalletAccountServiceImpl");
		jpaTransactionService = new JpaTransactionServiceImpl();
		if (jpaTransactionService != null)
			myLogger.info("jpaTransactionService instance created at WalletAccountServiceImpl");
		else
			myLogger.error("jpaTransactionService instance not created at WalletAccountServiceImpl");
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.TxHistoryService#viewtxHistory(java.
	 * time.LocalDateTime, java.time.LocalDateTime)
	 */
	@Override
	public List<TransactionHistory> viewtxHistory(BigInteger accId, LocalDateTime toDate, LocalDateTime fromDate)
			throws TxHistoryException {
		jpaTransactionService.beginTx();
		List<TransactionHistory> transactionHistories = txHistoryDao.viewtxHistory(accId, toDate, fromDate);
		jpaTransactionService.commitTx();
		return transactionHistories;
	}	
	/*
	 *  This is the viewAllTxHistory method which provide the list of all the tx of the specific account
	 * @param accId
	 * @return List<TransactionHistory>.
	 * @throws TxHistoryException */
	@Override
	public List<TransactionHistory> viewAllTxHistory(BigInteger accId) throws TxHistoryException{
		jpaTransactionService.beginTx();
		List<TransactionHistory> transactionHistories = txHistoryDao.viewAllTxHistory(accId);
		jpaTransactionService.commitTx();
		return transactionHistories;
	}
	/*
	 *  This is the viewAllTxHistory method which provide the list of all the tx of the specific account
	 * @param accId
	 * @return List<TransactionHistory>.
	 * @throws TxHistoryException */
	@Override
	public List<TransactionHistory> addTransactionHistory(WalletAccount walletAccount, String txType, String txDescription,
			double amtCredited, double amtDebited) throws TxHistoryException{
		jpaTransactionService.beginTx();
		List<TransactionHistory> transactionHistories = txHistoryDao.addTransactionHistory(walletAccount, txType, txDescription, amtCredited, amtDebited);
		jpaTransactionService.commitTx();
		return transactionHistories;
		
	}
	public static TxHistoryDao getPaymentWalletDao() {
		return txHistoryDao;
	}
	public static void setPaymentWalletDao(TxHistoryDao txHistoryDao) {
		TxHistoryServiceImpl.txHistoryDao = txHistoryDao;
	}
}
