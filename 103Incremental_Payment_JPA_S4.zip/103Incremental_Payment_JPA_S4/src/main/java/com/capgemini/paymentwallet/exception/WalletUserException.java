/**
 * 
 */
package com.capgemini.paymentwallet.exception;

/**
 * @author smitkuma
 *
 */
public class WalletUserException extends RuntimeException {

	public WalletUserException() {
		super();
	}
	public WalletUserException(String message) {
		super(message);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -7900677380899033365L;

}
