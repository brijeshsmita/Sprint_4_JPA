/**
 * 
 */
package com.capgemini.paymentwallet.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.model.WalletAccount;

/**
 * @author smitkuma
 *
 */
public interface WalletAccountService {
	
	public WalletAccount addMoney (BigInteger accId, double amount)throws PaymentWalletException;
	/*
	 *  This is the checkBalance method which returns balance form the specific WalletAccount
	 * @param accId
	 * @return BigDecimal.
	 * @throws PaymentWalletException */
	public BigDecimal checkBalance (BigInteger accId)throws PaymentWalletException; 
	/*
	 *  This is the viewWallet method which returns WalletAccount for the specific accId
	 * @param accId
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	public WalletAccount viewWallet (BigInteger accId)throws PaymentWalletException; 

	/*
	 *  This is the fundTransfer method which transfer amt from 1 WalletAccount to another
	 * @param fromAccId
	 * @param toAccId
	 * @param amount
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	public WalletAccount fundTransfer (BigInteger fromAccId, BigInteger toAccId, double amount)throws PaymentWalletException; 
	
}
