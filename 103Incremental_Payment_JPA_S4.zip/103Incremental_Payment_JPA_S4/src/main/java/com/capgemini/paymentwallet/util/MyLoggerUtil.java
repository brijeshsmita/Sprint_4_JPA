/**
 * 
 */
package com.capgemini.paymentwallet.util;

import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;

/**
 * @author smitkuma
 *
 */
public class MyLoggerUtil {

	public static void configure() {
		Properties props = System.getProperties();
		String userDir = props.getProperty("user.dir") + "/src/main/resources/";
		PropertyConfigurator.configure(userDir + "log4j.properties");
	}

}
