package com.capgemini.paymentwallet.model;


public enum WalletAccStatus {

    APPROVED,REJECTED,PENDING,CLOSED;

}
