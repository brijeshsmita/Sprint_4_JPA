/**
 * 
 */
package com.capgemini.paymentwallet.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.paymentwallet.dao.JpaTransactionDao;
import com.capgemini.paymentwallet.dao.JpaTransactionDaoImpl;
import com.capgemini.paymentwallet.dao.WalletAccountDao;
import com.capgemini.paymentwallet.dao.WalletAccountDaoImpl;
import com.capgemini.paymentwallet.exception.PaymentWalletException;
import com.capgemini.paymentwallet.model.TransactionHistory;
import com.capgemini.paymentwallet.model.WalletAccount;
import com.capgemini.paymentwallet.model.WalletUser;
import com.capgemini.paymentwallet.util.MyLoggerUtil;

/**
 * @author smitkuma
 *
 */
public class WalletAccountServiceImpl implements WalletAccountService {
	// prep work create instance of dao layer
	private static WalletAccountDao walletAccountDao;
	private static JpaTransactionDao jpaTransactionDao;
	private static Logger myLogger;
	/*
	 * static block to declare logger and create the instance of DaoImpl
	 */

	static {
		MyLoggerUtil.configure();
		myLogger = Logger.getLogger("WalletAccountServiceImpl.class");
		walletAccountDao = new WalletAccountDaoImpl();
		if (walletAccountDao != null)
			myLogger.info("walletAccountDao instance created at WalletAccountServiceImpl");
		else
			myLogger.error("walletAccountDao instance not created at WalletAccountServiceImpl");
		jpaTransactionDao = new JpaTransactionDaoImpl();
		if (jpaTransactionDao != null)
			myLogger.info("jpaTransactionDao instance created at WalletAccountServiceImpl");
		else
			myLogger.error("jpaTransactionDao instance not created at WalletAccountServiceImpl");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.WalletAccountService#addMoney(java.lang.
	 * BigInteger, java.lang.BigInteger, java.lang.BigDecimal)
	 * @param accId
	 * @param amount
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	@Override
	public WalletAccount addMoney(BigInteger accId, double amount) throws PaymentWalletException {
		jpaTransactionDao.beginTx();
		WalletAccount walletAccount = walletAccountDao.addMoney(accId, amount);
		jpaTransactionDao.commitTx();
		return walletAccount;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.WalletAccountService#checkBalance(java.
	 * lang.BigInteger, java.lang.BigInteger)
	*  This is the checkBalance method which returns balance form the specific WalletAccount
	 * @param accId
	 * @return BigDecimal.
	 * @throws PaymentWalletException */
	@Override
	public BigDecimal checkBalance(BigInteger accId) throws PaymentWalletException {
		jpaTransactionDao.beginTx();
		BigDecimal balance = walletAccountDao.checkBalance(accId);
		jpaTransactionDao.commitTx();
		return balance;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.WalletAccountService#viewWallet(java.
	 * lang.BigInteger, java.lang.BigInteger)
	 *  This is the viewWallet method which returns WalletAccount for the specific accId
	 * @param accId
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	@Override
	public WalletAccount viewWallet(BigInteger accId) throws PaymentWalletException {
		jpaTransactionDao.beginTx();
		WalletAccount walletAccount = walletAccountDao.viewWallet(accId);
		jpaTransactionDao.commitTx();
		return walletAccount;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.paymentwallet.services.WalletAccountService#fundTransfer(java.
	 * lang.BigInteger, java.lang.BigInteger, java.lang.BigInteger)
	 *  This is the fundTransfer method which transfer amt from 1 WalletAccount to another
	 * @param fromAccId
	 * @param toAccId
	 * @param amount
	 * @return WalletAccount.
	 * @throws PaymentWalletException */
	@Override
	public WalletAccount fundTransfer(BigInteger fromAccId, BigInteger toAccId, double amount)
			throws PaymentWalletException {
		jpaTransactionDao.beginTx();
		WalletAccount walletAccount = walletAccountDao.fundTransfer(fromAccId, toAccId, amount);
		jpaTransactionDao.commitTx();
		return walletAccount;
	}

	public static WalletAccountDao getPaymentWalletDao() {
		return walletAccountDao;
	}

	public static void setPaymentWalletDao(WalletAccountDao walletAccountDao) {
		WalletAccountServiceImpl.walletAccountDao = walletAccountDao;
	}

}
