/**
 * 
 */
package com.capgemini.paymentwallet.util;

/**
 * @author smitkuma
 *
 */
public class ErrorMessageUtil {

	public static final String ENTITY_MGR_ERROR_MSG = "Enity Manager factory Not Obtained at WalletAccountDaoImpl : ";
	public static final String VIEW_ALL_TX_HIS_ERROR = "Error: at WalletAccountDaoImpl viewAllTxHistory method : ";
	public static final String VIEW_WALLET_ERROR = "Error: at WalletAccountDaoImpl viewWallet method : ";
	public static final String REGISTER_ERROR = "Error: at WalletAccountDaoImpl register method : ";
	public static final String ADD_WALLET_ACC_ERROR = "Error: at WalletAccountDaoImpl register method : ";
	public static final String ADD_TX_HIS_ERROR = "Error: at WalletAccountDaoImpl addTransactionHistory method : ";
	public static final String FUND_TRNS_ERROR = "Error: at WalletAccountDaoImpl fundTransfer method : ";
	public static final String LOGIN_ERROR = "Error: at WalletAccountDaoImpl login method : " ;
	public static final String FIND_USER_ERROR = "Error: at WalletAccountDaoImpl findUserById method : ";
	public static final String ADD_MONEY_ERROR = "Error: at WalletAccountDaoImpl addMoney method : " ;
	public static final String CHECK_BAL_ERROR = "Error: at WalletAccountDaoImpl checkBalance method : ";
	public static final String VIEW_TX_HIS_ERROR = "Error: at WalletAccountDaoImpl viewTxHistory method : ";
	public static final String VIEW_WALLET_BY_ID_ERROR = "Error: at WalletAccountDaoImpl viewWalletByUserId method : ";
	public static final String LOGGER_ERROR_MSG = "Error while creating logger Object";

	private ErrorMessageUtil() {
	}
}
